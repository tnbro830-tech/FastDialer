FAST DIALER - floating call UI wala lightweight dialer

PHONE PE BUILD (AndroidIDE app se):
1. AndroidIDE install karo (github.com/AndroidIDEOfficial/AndroidIDE releases, arm64-v8a APK).
2. Pehli baar kholo: storage permission do aur setup/packages install hone do (internet chahiye).
3. MT Manager se FastDialer.zip ko extract karo (FastDialer folder banega).
4. AndroidIDE > Open existing project > FastDialer folder (jisme settings.gradle.kts hai).
5. Gradle sync poora hone do (pehli baar internet se files download hongi, 10-20 min).
6. Build > Run / assembleDebug. APK milega: app/build/outputs/apk/debug/app-debug.apk

APK install ke baad app kholo, upar blue banner ke 3 steps follow karo:
permissions -> overlay permission -> default Phone app.
Settings > Battery > Fast Dialer > Unrestricted bhi kar dena.

GITHUB se build karna ho to .github/workflows/build.yml dekho.

--- v1.1 (naye changes) ---
- Incoming call: Decline / Answer ke beech zyada gap (floating card me bhi, full screen me bhi: ek left ek right).
- Call ke dauran floating pill ab top-center me hi aati hai (jahan incoming card aata hai).
- Lock screen pe: ongoing call notification -> status bar me phone icon (Android 12+ pe green call chip + timer).
  Us pe touch karo to call screen khul jati hai. (Lock screen pe overlay Android allow nahi karta, isliye notification.)
- Proximity sensor: call me phone kaan pe lagao -> screen off, hatao -> screen on
  (speaker / bluetooth / headset pe screen on rehti hai, ringing me off nahi hoti).
- Home (Recents) screen: list upar scroll karo -> dial pad gayab, neeche kone me 3x3 dots button; us pe touch -> dial pad wapas.
  (Number type kiya hua ho to dial pad nahi chhupta.)
- Unknown number: saved contact nahi to network wala caller name upar dikhta hai (jaise default dialer). "CNAP" ka label kahin nahi.
- Recents me Incoming / Outgoing / Missed / Declined likha aata hai.
- Naye permission: WAKE_LOCK (proximity ke liye, normal permission hai, popup nahi aata).
