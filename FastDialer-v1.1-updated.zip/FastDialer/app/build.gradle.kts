plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fastdialer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fastdialer.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // Same key for every build, so new versions install over the old one
    signingConfigs {
        create("fixed") {
            storeFile = file("fastdialer.keystore")
            storePassword = "fastdialer"
            keyAlias = "fastdialer"
            keyPassword = "fastdialer"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            // signed with the fixed key above
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
// Koi external library nahi: APK chhota aur fast.
