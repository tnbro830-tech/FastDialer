package com.fastdialer

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Floating UI:
 *  - Incoming: upar chhota card (Answer / Decline)
 *  - Call ke dauran: draggable pill (Mute / Speaker / End + timer)
 * Flags FLAG_NOT_FOCUSABLE + FLAG_NOT_TOUCH_MODAL => game ka focus aur touch kabhi nahi rukta.
 */
class CallOverlay(private val svc: CallService) {
    private val ctx: Context = svc
    private val wm: WindowManager = ctx.getSystemService(WindowManager::class.java)
    private val nm: NotificationManager = ctx.getSystemService(NotificationManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val names = HashMap<String, String>()

    private var ringing: Call? = null
    private var ongoing: Call? = null

    private var inView: LinearLayout? = null
    private lateinit var inName: TextView
    private lateinit var inSub: TextView
    private lateinit var inAvatar: TextView

    private var onView: LinearLayout? = null
    private lateinit var onName: TextView
    private lateinit var onTime: TextView
    private class Tog(val box: FrameLayout, val g: Glyph)

    private lateinit var btnMute: Tog
    private lateinit var btnSpeaker: Tog
    private var pillX = ctx.dp(12)
    private var pillY = ctx.dp(140)

    private val tick = object : Runnable {
        override fun run() {
            refreshTimer()
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- main update ----------
    fun update(calls: List<Call>) {
        val live = calls.filter { it.state != Call.STATE_DISCONNECTED }
        ringing = live.firstOrNull { it.state == Call.STATE_RINGING }
        ongoing = live.firstOrNull { it.state != Call.STATE_RINGING }
        if (live.isEmpty()) {
            hide()
            return
        }
        if (InCallActivity.visible || InCallActivity.launching()) {
            removeIncoming()
            removeOngoing()
            nm.cancel(7)
            return
        }
        wasLocked = isLocked()
        // Lock screen pe overlay nahi dikhta => ongoing-call notification (status bar me phone icon / green chip,
        // touch karne pe call screen). Overlay permission na ho tab bhi yahi.
        if (wasLocked || !Settings.canDrawOverlays(ctx)) {
            removeIncoming()
            removeOngoing()
            postCallNotification()
            return
        }
        nm.cancel(7)
        val r = ringing
        if (r != null) showIncoming(r) else removeIncoming()
        val o = ongoing
        if (o != null) showOngoing(o) else removeOngoing()
    }

    fun hide() {
        removeIncoming()
        removeOngoing()
        nm.cancel(7)
    }

    private var wasLocked = false

    private fun isLocked(): Boolean = try {
        ctx.getSystemService(KeyguardManager::class.java).isKeyguardLocked
    } catch (_: Exception) {
        false
    }

    /** CallService har second bulata hai: phone lock/unlock hua to UI badal do */
    fun checkLock(calls: List<Call>) {
        if (isLocked() != wasLocked) update(calls)
    }

    // ---------- helpers ----------
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    )

    private fun numberOf(call: Call): String =
        call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown"

    private fun nameFor(number: String): String? {
        if (number == "Unknown") return null
        names[number]?.let { return it.ifEmpty { null } }
        var name = ""
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" }
        } catch (_: Exception) {
        }
        names[number] = name
        return name.ifEmpty { null }
    }

    /** Saved contact name, warna network se aaya naam (jaise default dialer me dikhta hai), warna null */
    private fun displayNameFor(call: Call): String? = nameFor(numberOf(call)) ?: networkName(call)

    private fun initial(s: String): String = s.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"

    private fun iconBtn(res: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(ctx)
        v.setImageResource(res)
        v.scaleType = ImageView.ScaleType.CENTER_INSIDE
        v.setPadding(ctx.dp(9), ctx.dp(9), ctx.dp(9), ctx.dp(9))
        v.setOnClickListener { onClick() }
        return v
    }

    /** Gol button with handset: rotate 0 = answer (hara), 135 = decline/end (laal) */
    private fun circleBtn(color: Int, rotateDeg: Float, onClick: () -> Unit): ImageView {
        val v = iconBtn(R.drawable.ic_call, onClick)
        v.setColorFilter(Color.WHITE)
        v.rotation = rotateDeg
        v.setPadding(ctx.dp(11), ctx.dp(11), ctx.dp(11), ctx.dp(11))
        v.background = ctx.ripple(color, circle = true, rippleColor = 0x44FFFFFF)
        return v
    }

    /** Drag a floating window with your finger; a plain tap runs onTap */
    private fun makeDraggable(
        v: View,
        root: View,
        p: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        onMoved: (Int, Int) -> Unit = { _, _ -> }
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = ctx.dp(8)
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        p.x = startX + dx.toInt()
                        p.y = startY + dy.toInt()
                        onMoved(p.x, p.y)
                        try {
                            wm.updateViewLayout(root, p)
                        } catch (_: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                }
            }
            true
        }
    }

    // ---------- incoming card ----------
    private fun showIncoming(call: Call) {
        val number = numberOf(call)
        val name = displayNameFor(call)
        if (inView == null) buildIncoming()
        inName.text = name ?: number
        inSub.text = if (name != null && number != "Unknown") "$number • Incoming call" else "Incoming call"
        inAvatar.text = initial(name ?: number)
    }

    private fun buildIncoming() {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = ctx.bg(0xF2142520.toInt(), 26)
        card.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        card.elevation = ctx.dp(8).toFloat()

        inAvatar = ctx.label("?", 20f, Color.WHITE, true)
        inAvatar.gravity = Gravity.CENTER
        inAvatar.background = ctx.bg(0xFF5C6B64.toInt(), circle = true)
        card.addView(inAvatar, lin(ctx.dp(48), ctx.dp(48)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(12), 0, ctx.dp(8), 0)
        inName = ctx.label("", 17f, Color.WHITE, true)
        inName.isSingleLine = true
        inName.ellipsize = TextUtils.TruncateAt.END
        inSub = ctx.label("", 14f, 0xFFAEAEB2.toInt())
        inSub.isSingleLine = true
        inSub.ellipsize = TextUtils.TruncateAt.END
        col.addView(inName)
        val sp = lin(WRAP, WRAP)
        sp.topMargin = ctx.dp(2)
        col.addView(inSub, sp)
        card.addView(col, lin(0, WRAP, 1f))

        val decline = circleBtn(XI_RED, 135f) { ringing?.reject(false, null) }
        val answer = circleBtn(XI_GREEN, 0f) { ringing?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        val ld = lin(ctx.dp(46), ctx.dp(46))
        ld.rightMargin = ctx.dp(26)
        val la = lin(ctx.dp(46), ctx.dp(46))
        card.addView(decline, ld)
        card.addView(answer, la)

        val w = minOf(ctx.resources.displayMetrics.widthPixels - ctx.dp(24), ctx.dp(420))
        val p = params(w, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = ctx.dp(10)
        makeDraggable(card, card, p, onTap = { InCallActivity.open(ctx) })
        try {
            wm.addView(card, p)
            inView = card
        } catch (e: Exception) {
            inView = null
            postCallNotification()
        }
    }

    private fun removeIncoming() {
        inView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        inView = null
    }

    // ---------- ongoing pill ----------
    private fun showOngoing(call: Call) {
        val number = numberOf(call)
        if (onView == null) buildOngoing()
        onName.text = displayNameFor(call) ?: number
        refreshTimer()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
    }

    private fun toggleBtn(kind: Int, onClick: () -> Unit): Tog {
        val g = Glyph(ctx, kind)
        g.color = Color.WHITE
        val f = FrameLayout(ctx)
        f.addView(g, FrameLayout.LayoutParams(ctx.dp(20), ctx.dp(20), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        return Tog(f, g)
    }

    private fun styleToggle(t: Tog, on: Boolean) {
        t.g.color = if (on) Color.BLACK else Color.WHITE
        t.box.background = ctx.ripple(
            if (on) Color.WHITE else 0x40FFFFFF, circle = true, rippleColor = 0x33888888
        )
    }

    private fun buildOngoing() {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = ctx.bg(0xF2102019.toInt(), 30)
        card.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        card.elevation = ctx.dp(6).toFloat()

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        onName = ctx.label("", 14f, Color.WHITE, true)
        onName.isSingleLine = true
        onName.ellipsize = TextUtils.TruncateAt.END
        onName.maxWidth = ctx.dp(90)
        onTime = ctx.label("", 13f, Color.WHITE)
        col.addView(onName)
        val st = lin(WRAP, WRAP)
        st.topMargin = ctx.dp(2)
        col.addView(onTime, st)
        val lc = lin(WRAP, WRAP)
        lc.rightMargin = ctx.dp(10)
        card.addView(col, lc)

        btnMute = toggleBtn(Glyph.K_MIC) {
            svc.setMuted(!(svc.callAudioState?.isMuted ?: false))
        }
        btnSpeaker = toggleBtn(Glyph.K_SPEAKER) {
            val on = svc.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
            svc.setAudioRoute(if (on) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
        }
        val end = circleBtn(XI_RED, 135f) { ongoing?.disconnect() }
        styleToggle(btnMute, false)
        styleToggle(btnSpeaker, false)

        for (b in listOf<View>(btnMute.box, btnSpeaker.box, end)) {
            val l = lin(ctx.dp(38), ctx.dp(38))
            l.rightMargin = ctx.dp(6)
            card.addView(b, l)
        }

        val p = params(WRAP, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = 0
        p.y = ctx.dp(10)

        makeDraggable(col, card, p, onTap = { InCallActivity.open(ctx) }) { x, y ->
            pillX = x
            pillY = y
        }
        makeDraggable(card, card, p, onTap = { InCallActivity.open(ctx) }) { x, y ->
            pillX = x
            pillY = y
        }

        try {
            wm.addView(card, p)
            onView = card
            svc.callAudioState?.let { audioChanged(it) }
        } catch (e: Exception) {
            onView = null
            postCallNotification()
        }
    }

    private fun removeOngoing() {
        onView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        onView = null
        ui.removeCallbacks(tick)
    }

    fun audioChanged(a: CallAudioState) {
        if (onView == null) return
        btnMute.g.kind = if (a.isMuted) Glyph.K_MIC_OFF else Glyph.K_MIC
        styleToggle(btnMute, a.isMuted)
        styleToggle(btnSpeaker, a.route == CallAudioState.ROUTE_SPEAKER)
    }

    private fun refreshTimer() {
        if (onView == null) return
        val c = ongoing ?: return
        onTime.text = when (c.state) {
            Call.STATE_ACTIVE -> elapsed(c)
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            else -> "…"
        }
    }

    private fun elapsed(c: Call): String {
        val t = c.details.connectTimeMillis
        if (t <= 0) return "00:00"
        val s = ((System.currentTimeMillis() - t) / 1000).toInt().coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    // ---------- notification: lock screen pe ya overlay permission na ho tab ----------
    // Ongoing call me status bar me phone icon aata hai (Android 12+ pe green call chip + timer),
    // us pe touch karne se call screen khul jati hai.
    private fun ensureChannels() {
        val ch = NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
        val on = NotificationChannel("ongoing_call", "Ongoing call", NotificationManager.IMPORTANCE_LOW)
        on.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(on)
    }

    private fun actionPi(act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, CallActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun postCallNotification() {
        val ring = ringing
        val on = ongoing
        val c = ring ?: on ?: return
        val who = displayNameFor(c) ?: numberOf(c)
        ensureChannels()
        val channel = if (ring != null) "calls" else "ongoing_call"
        val open = PendingIntent.getActivity(
            ctx, 11, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val connected = if (ring == null && on != null && on.state == Call.STATE_ACTIVE) {
            on.details.connectTimeMillis
        } else {
            0L
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val person = Person.Builder().setName(who).setImportant(true).build()
                val style = if (ring != null) {
                    Notification.CallStyle.forIncomingCall(person, actionPi("decline"), actionPi("answer"))
                } else {
                    Notification.CallStyle.forOngoingCall(person, actionPi("end"))
                }
                val nb = Notification.Builder(ctx, channel)
                    .setSmallIcon(R.drawable.ic_call)
                    .setContentIntent(open)
                    .setCategory(Notification.CATEGORY_CALL)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setStyle(style)
                if (connected > 0) {
                    nb.setUsesChronometer(true)
                    nb.setWhen(connected)
                }
                nm.notify(7, nb.build())
                return
            } catch (_: Exception) {
                // purane Android / koi dikkat: neeche wali simple notification
            }
        }

        val b = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(who)
            .setContentText(if (ring != null) "Incoming call" else "Ongoing call")
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (ring != null) {
            b.addAction(action("Answer", "answer"))
            b.addAction(action("Decline", "decline"))
        } else {
            if (connected > 0) {
                b.setUsesChronometer(true)
                b.setWhen(connected)
            }
            b.addAction(action("End", "end"))
        }
        nm.notify(7, b.build())
    }

    private fun action(title: String, act: String): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(ctx, R.drawable.ic_call), title, actionPi(act)).build()
}
