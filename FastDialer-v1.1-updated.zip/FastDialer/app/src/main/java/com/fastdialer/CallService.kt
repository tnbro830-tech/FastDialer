package com.fastdialer

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

/** System jab call deta hai (incoming/outgoing) to ye service chalti hai. Full-screen nahi kholti, sirf floating overlay. */
class CallService : InCallService() {
    companion object {
        @Volatile
        var instance: CallService? = null
    }

    private val calls = ArrayList<Call>()
    private lateinit var overlay: CallOverlay
    private val handler = Handler(Looper.getMainLooper())
    private var proxLock: PowerManager.WakeLock? = null

    /** Har second dekhta hai ki phone lock/unlock hua ya nahi (lock pe overlay ki jagah notification chip lagti hai) */
    private val lockTick = object : Runnable {
        override fun run() {
            if (calls.isEmpty()) return
            overlay.checkLock(calls)
            handler.postDelayed(this, 1000)
        }
    }

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            overlay.update(calls)
            updateProximity()
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            overlay.update(calls)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        overlay = CallOverlay(this)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releaseProximity()
        overlay.hide()
        instance = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        calls.add(call)
        call.registerCallback(cb)
        maybeOpenUi(call)
        overlay.update(calls)
        updateProximity()
        handler.removeCallbacks(lockTick)
        handler.postDelayed(lockTick, 1000)
    }

    /** Outgoing calls (and incoming ones while locked / screen off) open the full-screen call screen. */
    private fun maybeOpenUi(call: Call) {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        val locked = km.isKeyguardLocked || !pm.isInteractive
        if (call.state != Call.STATE_RINGING || locked) InCallActivity.open(this)
    }

    fun refreshUi() {
        overlay.update(calls)
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        calls.remove(call)
        overlay.update(calls)
        updateProximity()
        if (calls.isEmpty()) handler.removeCallbacks(lockTick)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        overlay.audioChanged(audioState)
        updateProximity()
    }

    fun ringing(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING }
    fun ongoing(): Call? =
        calls.firstOrNull { it.state != Call.STATE_RINGING && it.state != Call.STATE_DISCONNECTED }

    // ---------- proximity sensor: kaan pe lagao => screen off, hatao => screen on ----------
    // Sirf tab jab call chal rahi ho/dial ho rahi ho aur awaaz earpiece se aa rahi ho
    // (speaker, bluetooth, headset pe screen on hi rehti hai). Ringing me off nahi hoti.
    private fun updateProximity() {
        val ringing = calls.any { it.state == Call.STATE_RINGING }
        val live = calls.any {
            it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING || it.state == Call.STATE_CONNECTING
        }
        val route = callAudioState?.route ?: CallAudioState.ROUTE_EARPIECE
        if (live && !ringing && route == CallAudioState.ROUTE_EARPIECE) acquireProximity() else releaseProximity()
    }

    private fun acquireProximity() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) return
            var wl = proxLock
            if (wl == null) {
                wl = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "FastDialer:proximity")
                wl.setReferenceCounted(false)
                proxLock = wl
            }
            if (!wl.isHeld) wl.acquire(6 * 60 * 60 * 1000L)
        } catch (_: Exception) {
        }
    }

    private fun releaseProximity() {
        try {
            val wl = proxLock ?: return
            // WAIT_FOR_NO_PROXIMITY: agar call kaan pe lagi hue hi kat jaye to screen tab tak off rehti hai jab tak phone hataya na jaye
            if (wl.isHeld) wl.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY)
        } catch (_: Exception) {
        }
    }
}

/** Notification buttons (agar overlay permission na ho to fallback) */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val s = CallService.instance ?: return
        when (intent.action) {
            "answer" -> s.ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY)
            "decline" -> s.ringing()?.reject(false, null)
            "end" -> s.ongoing()?.disconnect()
        }
    }
}
