package com.cbdialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

fun placeCall(ctx: Context, number: String) {
    val n = number.trim()
    if (n.isEmpty()) return
    try {
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle())
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Please allow the call permission", Toast.LENGTH_SHORT).show()
    }
}


/** Sabse nayi call (jo aayi ho ya jo maine milai ho) ka number: dial pad khali ho to green button isi ko lagata hai */
fun callLastNumber(ctx: Context) {
    if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(ctx, "Please allow the call log permission", Toast.LENGTH_SHORT).show()
        return
    }
    var num = ""
    try {
        val args = Bundle()
        args.putString(
            ContentResolver.QUERY_ARG_SQL_SELECTION,
            CallLog.Calls.NUMBER + " IS NOT NULL AND " + CallLog.Calls.NUMBER + " != ''"
        )
        args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
        args.putInt(ContentResolver.QUERY_ARG_LIMIT, 1)
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER), args, null)?.use {
            if (it.moveToFirst()) num = it.getString(0) ?: ""
        }
    } catch (_: Exception) {
    }
    if (num.isBlank()) {
        Toast.makeText(ctx, "No recent call", Toast.LENGTH_SHORT).show()
    } else {
        placeCall(ctx, num)
    }
}

/** WhatsApp ke liye number: country code ke saath, sirf digits */
fun waNumber(ctx: Context, number: String): String {
    val raw = number.trim()
    val digits = raw.filter { it.isDigit() }
    if (raw.startsWith("+")) return digits
    var iso = ""
    try {
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        iso = tm?.simCountryIso ?: ""
        if (iso.isEmpty()) iso = tm?.networkCountryIso ?: ""
    } catch (_: Exception) {
    }
    if (iso.isEmpty()) iso = java.util.Locale.getDefault().country
    if (iso.isEmpty()) iso = "IN"
    val e164 = try {
        PhoneNumberUtils.formatNumberToE164(raw, iso.uppercase())
    } catch (_: Exception) {
        null
    }
    return (e164 ?: digits).filter { it.isDigit() }
}

fun openWhatsApp(ctx: Context, number: String) {
    val n = waNumber(ctx, number)
    if (n.isEmpty()) return
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n"))
    if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(Intent(i).setPackage("com.whatsapp"))
    } catch (e: Exception) {
        try {
            ctx.startActivity(i)
        } catch (e2: Exception) {
            Toast.makeText(ctx, "WhatsApp not found", Toast.LENGTH_SHORT).show()
        }
    }
}

fun openSms(ctx: Context, number: String) {
    try {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
        if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No messaging app found", Toast.LENGTH_SHORT).show()
    }
}

fun addContact(ctx: Context, number: String, name: String?) {
    try {
        val i = Intent(Intent.ACTION_INSERT_OR_EDIT)
        i.type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
        i.putExtra(ContactsContract.Intents.Insert.PHONE, number)
        if (!name.isNullOrBlank()) i.putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No contacts app found", Toast.LENGTH_SHORT).show()
    }
}

/** Call log ki ye entries delete (WRITE_CALL_LOG chahiye; default dialer ko mil jata hai) */
fun deleteCallIds(ctx: Context, ids: List<Long>): Boolean {
    if (ids.isEmpty()) return false
    return try {
        ctx.contentResolver.delete(
            CallLog.Calls.CONTENT_URI,
            CallLog.Calls._ID + " IN (" + ids.joinToString(",") + ")",
            null
        ) > 0
    } catch (e: Exception) {
        false
    }
}

class SheetItem(val label: String, val icon: Int, val danger: Boolean, val onClick: () -> Unit)

/** Neeche se aati rounded sheet: upar naam/number, neeche options */
fun showActionSheet(a: Activity, title: String, sub: String, items: List<SheetItem>) {
    if (a.isFinishing) return
    val pal = a.palette()
    val d = Dialog(a)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)

    val sheet = LinearLayout(a)
    sheet.orientation = LinearLayout.VERTICAL
    sheet.background = a.bgTop(pal.sheet, 26)
    sheet.setPadding(0, a.dp(10), 0, a.dp(18))

    val handle = View(a)
    handle.background = a.bg(pal.avatar, 3)
    val hl = lin(a.dp(38), a.dp(5))
    hl.gravity = Gravity.CENTER_HORIZONTAL
    hl.bottomMargin = a.dp(12)
    sheet.addView(handle, hl)

    val t = a.label(title, 18f, pal.text, true)
    t.gravity = Gravity.CENTER
    t.isSingleLine = true
    t.ellipsize = TextUtils.TruncateAt.END
    t.setPadding(a.dp(20), 0, a.dp(20), 0)
    sheet.addView(t, lin(MATCH, WRAP))
    if (sub.isNotEmpty()) {
        val st = a.label(sub, 13f, pal.sub)
        st.gravity = Gravity.CENTER
        val sl = lin(MATCH, WRAP)
        sl.topMargin = a.dp(4)
        sheet.addView(st, sl)
    }
    val gap = lin(MATCH, a.dp(10))
    sheet.addView(View(a), gap)

    for (entry in items) {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(a.dp(26), 0, a.dp(26), 0)
        row.background = a.ripple(Color.TRANSPARENT, rippleColor = 0x22888888)
        val g = Glyph(a, entry.icon)
        g.color = if (entry.danger) XI_RED else pal.text
        row.addView(g, lin(a.dp(24), a.dp(24)))
        val tv = a.label(entry.label, 16f, if (entry.danger) XI_RED else pal.text)
        val tl = lin(WRAP, WRAP)
        tl.leftMargin = a.dp(18)
        row.addView(tv, tl)
        row.setOnClickListener {
            d.dismiss()
            entry.onClick()
        }
        sheet.addView(row, lin(MATCH, a.dp(54)))
    }

    d.setContentView(sheet)
    d.window?.let { w ->
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.45f)
    }
    sheet.translationY = a.dp(500).toFloat()
    try {
        d.show()
    } catch (_: Exception) {
        return
    }
    sheet.animate().translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator(1.8f)).start()
}

/** 83 -> "1m 23s" */
fun durText(sec: Long): String = when {
    sec <= 0 -> ""
    sec < 60 -> "${sec}s"
    sec < 3600 -> "${sec / 60}m ${sec % 60}s"
    else -> "${sec / 3600}h ${sec % 3600 / 60}m"
}

fun callTypeText(type: Int): String = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
    CallLog.Calls.INCOMING_TYPE -> "Incoming"
    CallLog.Calls.MISSED_TYPE -> "Missed"
    CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> "Declined"
    CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"
    else -> ""
}

/** In-app Settings screen (block spam, SIM / data usage, etc.) */
fun openSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
    } catch (e: Exception) {
    }
}

fun openAppSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
        )
    } catch (e: Exception) {
    }
}

/** Recents / Contacts screen: title, search bar and the list (ListView keeps it light) */
class ListScreen(
    private val ctx: Context,
    title: String,
    emptyText: String,
    private val contactsMode: Boolean
) {
    class Row(
        val title: String,
        val sub: String,
        val number: String,
        val missed: Boolean,
        val header: Boolean = false,
        val ids: List<Long> = emptyList(),
        val name: String? = null
    )

    private class ItemView(c: Context, pal: Pal, showInfo: Boolean) : LinearLayout(c) {
        val avatarBg = FrameLayout(c)
        val initial: TextView = c.label("", 18f, Color.WHITE, true)
        val person = Glyph(c, Glyph.K_PERSON_FILL)
        val title: TextView = c.label("", 16f, pal.text, true)
        val sub: TextView = c.label("", 12f, pal.sub)
        val info = FrameLayout(c)

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(16), c.dp(8), c.dp(16), c.dp(8))
            initial.gravity = Gravity.CENTER
            person.color = if (pal.dark) 0xFFB0B0B5.toInt() else Color.WHITE
            avatarBg.addView(initial, FrameLayout.LayoutParams(MATCH, MATCH))
            avatarBg.addView(person, FrameLayout.LayoutParams(c.dp(26), c.dp(26), Gravity.CENTER))
            addView(avatarBg, lin(c.dp(44), c.dp(44)))

            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(c.dp(14), 0, c.dp(8), 0)
            title.isSingleLine = true
            title.ellipsize = TextUtils.TruncateAt.END
            sub.isSingleLine = true
            sub.ellipsize = TextUtils.TruncateAt.END
            col.addView(title)
            val sp = lin(WRAP, WRAP)
            sp.topMargin = c.dp(3)
            col.addView(sub, sp)
            addView(col, lin(0, WRAP, 1f))

            if (showInfo) {
                info.background = c.bg(pal.avatar, circle = true)
                val chev = Glyph(c, Glyph.K_CHEVRON)
                chev.color = pal.text
                info.addView(chev, FrameLayout.LayoutParams(c.dp(18), c.dp(18), Gravity.CENTER))
                addView(info, lin(c.dp(32), c.dp(32)))
            }
        }
    }

    var onSearchFocus: ((Boolean) -> Unit)? = null
    var onScrollUp: (() -> Unit)? = null
    var onScrollDown: (() -> Unit)? = null

    private val pal = ctx.palette()
    private val all = ArrayList<Row>()
    private val rows = ArrayList<Row>()
    private var query = ""
    private var lastLoad = 0L
    private val list = ListView(ctx)
    val view = FrameLayout(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position].header) 0 else 1
        override fun areAllItemsEnabled() = false
        override fun isEnabled(position: Int) = !rows[position].header

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            if (r.header) {
                val t = (convertView as? TextView) ?: ctx.label("", 12f, pal.sub, true)
                t.setPadding(ctx.dp(20), ctx.dp(14), ctx.dp(20), ctx.dp(4))
                t.text = r.title
                return t
            }
            val v = (convertView as? ItemView) ?: ItemView(ctx, pal, !contactsMode)
            v.title.text = r.title
            v.title.setTextColor(if (r.missed) XI_RED else pal.text)
            v.sub.text = r.sub
            v.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
            val ch = r.title.firstOrNull { it.isLetter() }
            if (ch != null) {
                val col = AV_COLORS[(r.title.hashCode() and 0x7fffffff) % AV_COLORS.size]
                v.avatarBg.background = ctx.bg(col, circle = true)
                v.initial.text = ch.toString().uppercase()
                v.initial.visibility = View.VISIBLE
                v.person.visibility = View.GONE
            } else {
                v.avatarBg.background = ctx.bg(pal.avatar, circle = true)
                v.initial.visibility = View.GONE
                v.person.visibility = View.VISIBLE
            }
            v.info.setOnClickListener { openContact(r) }
            return v
        }
    }

    init {
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(0x22888888)
        list.isFastScrollEnabled = contactsMode
        list.setOnItemClickListener { _, _, p, _ ->
            if (p in rows.indices && !rows[p].header) placeCall(ctx, rows[p].number)
        }
        // Recents me kisi row ko dabake rakho => Add contact / Delete / WhatsApp / Message
        list.setOnItemLongClickListener { _, _, p, _ ->
            if (!contactsMode && p in rows.indices && !rows[p].header) {
                showRowMenu(rows[p])
                true
            } else {
                false
            }
        }
        // upar scroll karne (list neeche jaane) pe onScrollUp bulao
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            private var state = AbsListView.OnScrollListener.SCROLL_STATE_IDLE
            private var lastFirst = 0
            private var lastTop = 0

            override fun onScrollStateChanged(v: AbsListView?, s: Int) {
                state = s
            }

            override fun onScroll(v: AbsListView?, first: Int, visible: Int, total: Int) {
                val c = v?.getChildAt(0) ?: return
                val top = c.top
                if (state != AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    val moved = if (first == lastFirst) lastTop - top else if (first > lastFirst) 100 else -100
                    if (moved > 6) onScrollUp?.invoke() else if (moved < -6) onScrollDown?.invoke()
                }
                lastFirst = first
                lastTop = top
            }
        })

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        // title bar with the settings gear
        val bar = FrameLayout(ctx)
        bar.addView(
            ctx.label(title, 18f, pal.text, true),
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER)
        )
        val gear = Glyph(ctx, Glyph.K_GEAR)
        gear.color = pal.text
        val gearCell = ctx.iconCell(gear, 22) { openSettings(ctx) }
        val gl = FrameLayout.LayoutParams(ctx.dp(48), ctx.dp(48), Gravity.END or Gravity.CENTER_VERTICAL)
        gl.rightMargin = ctx.dp(8)
        bar.addView(gearCell, gl)
        col.addView(bar, lin(MATCH, ctx.dp(52)))

        // search bar
        val sbar = LinearLayout(ctx)
        sbar.orientation = LinearLayout.HORIZONTAL
        sbar.gravity = Gravity.CENTER_VERTICAL
        sbar.background = ctx.bg(pal.fill, 22)
        sbar.setPadding(ctx.dp(14), 0, ctx.dp(8), 0)
        val sg = Glyph(ctx, Glyph.K_SEARCH)
        sg.color = pal.sub
        sbar.addView(sg, lin(ctx.dp(18), ctx.dp(18)))
        val et = EditText(ctx)
        et.hint = "Search contacts"
        et.setHintTextColor(pal.sub)
        et.setTextColor(pal.text)
        et.textSize = 15f
        et.isSingleLine = true
        et.background = null
        et.setPadding(ctx.dp(10), 0, ctx.dp(10), 0)
        et.setOnFocusChangeListener { _, f -> onSearchFocus?.invoke(f) }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                applyFilter()
            }
        })
        sbar.addView(et, lin(0, MATCH, 1f))
        val sl = lin(MATCH, ctx.dp(44))
        sl.setMargins(ctx.dp(16), ctx.dp(6), ctx.dp(16), ctx.dp(8))
        col.addView(sbar, sl)

        if (contactsMode) {
            val ac = ctx.label("All contacts", 13f, pal.sub)
            ac.setPadding(ctx.dp(20), ctx.dp(4), ctx.dp(20), ctx.dp(4))
            col.addView(ac, lin(MATCH, WRAP))
        }

        col.addView(list, lin(MATCH, 0, 1f))
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val empty = ctx.label(emptyText, 14f, pal.sub)
        empty.gravity = Gravity.CENTER
        view.addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        list.emptyView = empty

        if (contactsMode) {
            val fab = FrameLayout(ctx)
            fab.background = ctx.bg(XI_GREEN, circle = true)
            fab.elevation = ctx.dp(6).toFloat()
            val plus = Glyph(ctx, Glyph.K_PLUS)
            plus.color = Color.WHITE
            fab.addView(plus, FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.CENTER))
            fab.setOnClickListener {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI))
                } catch (e: Exception) {
                }
            }
            val fl = FrameLayout.LayoutParams(ctx.dp(56), ctx.dp(56), Gravity.BOTTOM or Gravity.END)
            fl.setMargins(0, 0, ctx.dp(20), ctx.dp(20))
            view.addView(fab, fl)
        }
    }

    /** Arrow dabane par: us number ka poora interface (history + actions) */
    private fun openContact(r: Row) {
        try {
            val i = Intent(ctx, ContactActivity::class.java)
            i.putExtra("number", r.number)
            i.putExtra("name", r.name)
            i.putExtra("ids", r.ids.toLongArray())
            ctx.startActivity(i)
        } catch (_: Exception) {
        }
    }

    /** Row pe long press: Add contact / Delete / Send WhatsApp message / Message */
    private fun showRowMenu(r: Row) {
        val a = ctx as? Activity ?: return
        val who = r.name ?: r.number.ifBlank { "Unknown" }
        val items = ArrayList<SheetItem>()
        if (r.number.isNotBlank()) {
            items.add(SheetItem("Add contact", Glyph.K_ADD_PERSON, false) { addContact(ctx, r.number, r.name) })
        }
        items.add(SheetItem("Delete", Glyph.K_TRASH, true) { confirmDelete(a, r) })
        if (r.number.isNotBlank()) {
            items.add(SheetItem("Send WhatsApp message", Glyph.K_BUBBLE, false) { openWhatsApp(ctx, r.number) })
            items.add(SheetItem("Message", Glyph.K_CHAT, false) { openSms(ctx, r.number) })
        }
        showActionSheet(a, who, if (r.name != null) r.number else "", items)
    }

    private fun confirmDelete(a: Activity, r: Row) {
        try {
            AlertDialog.Builder(a)
                .setTitle("Delete")
                .setMessage("Remove this call from recents?")
                .setPositiveButton("Delete") { _, _ ->
                    if (deleteCallIds(ctx, r.ids)) {
                        lastLoad = 0L
                        loadCalls()
                    } else {
                        Toast.makeText(ctx, "Could not delete (allow call log permission)", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (_: Exception) {
        }
    }

    private fun applyFilter() {
        rows.clear()
        if (query.isEmpty()) {
            rows.addAll(all)
        } else {
            rows.addAll(all.filter { !it.header && (it.title.contains(query, true) || it.number.contains(query)) })
        }
        adapter.notifyDataSetChanged()
    }

    private fun publish(out: List<Row>) {
        view.post {
            all.clear()
            all.addAll(out)
            applyFilter()
        }
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun tooSoon(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (all.isNotEmpty() && now - lastLoad < 800) return true
        lastLoad = now
        return false
    }

    fun loadCalls() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        if (tooSoon()) return
        Thread {
            val out = ArrayList<Row>()
            val counts = ArrayList<Int>()
            val idLists = ArrayList<ArrayList<Long>>()
            var lastKey = ""
            try {
                val args = Bundle()
                args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
                args.putInt(ContentResolver.QUERY_ARG_LIMIT, 100)
                val proj = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE,
                    CallLog.Calls.DURATION, CallLog.Calls._ID
                )
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(0) ?: ""
                        val name = cleanName(c.getString(1), num)
                        val id = c.getLong(5)
                        val type = c.getInt(2)
                        val date = c.getLong(3)
                        val dur = durText(c.getLong(4))
                        val time = if (DateUtils.isToday(date)) {
                            DateUtils.formatDateTime(ctx, date, DateUtils.FORMAT_SHOW_TIME)
                        } else {
                            DateUtils.formatDateTime(
                                ctx, date, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_ALL
                            )
                        }
                        val hasName = name != null
                        val title = name ?: (if (num.isBlank()) "Unknown" else num)
                        val missed = type == CallLog.Calls.MISSED_TYPE
                        val dir = callTypeText(type)
                        val sub = (if (dir.isEmpty()) "" else dir + " \u2022 ") + time +
                            (if (dur.isEmpty()) "" else " \u2022 $dur") +
                            (if (hasName) " \u2022 $num" else "")
                        val key = num + "|" + type
                        if (out.isNotEmpty() && key == lastKey) {
                            counts[counts.size - 1] = counts[counts.size - 1] + 1
                            idLists[idLists.size - 1].add(id)
                        } else {
                            out.add(Row(title, sub, num, missed, false, emptyList(), name))
                            counts.add(1)
                            idLists.add(arrayListOf(id))
                            lastKey = key
                        }
                    }
                }
            } catch (_: Exception) {
            }
            val grouped = ArrayList<Row>()
            for (k in out.indices) {
                val r = out[k]
                if (counts[k] > 1) {
                    grouped.add(Row(r.title + " (" + counts[k] + ")", r.sub, r.number, r.missed, false, idLists[k], r.name))
                } else {
                    grouped.add(Row(r.title, r.sub, r.number, r.missed, false, idLists[k], r.name))
                }
            }
            publish(grouped)
        }.start()
    }

    fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        if (tooSoon()) return
        Thread {
            val out = ArrayList<Row>()
            val favs = ArrayList<Row>()
            val rest = ArrayList<Row>()
            val seen = HashSet<String>()
            try {
                val pUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val pName = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                val pNum = ContactsContract.CommonDataKinds.Phone.NUMBER
                ctx.contentResolver.query(
                    pUri, arrayOf(pName, pNum, "starred"), null, null,
                    pName + " COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(1) ?: continue
                        val name = c.getString(0) ?: num
                        val starred = c.getInt(2) == 1
                        if (seen.add(name + "|" + num.filter { it.isDigit() })) {
                            if (starred) favs.add(Row(name, num, num, false))
                            else rest.add(Row(name, num, num, false))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (favs.isNotEmpty()) {
                out.add(Row("FAVORITES", "", "", false, true))
                out.addAll(favs)
            }
            var last = ""
            for (r in rest) {
                val ch = r.title.firstOrNull { it.isLetter() }
                val key = if (ch != null) ch.toString().uppercase() else "#"
                if (key != last) {
                    out.add(Row(key, "", "", false, true))
                    last = key
                }
                out.add(r)
            }
            publish(out)
        }.start()
    }
}

/** The keypad sheet: plain numbers (no button backgrounds), menu / green call / dots */
class DialSheet(private val ctx: Context) : LinearLayout(ctx) {
    private val pal = ctx.palette()
    private val sb = StringBuilder()
    private val numView = ctx.label("", 30f, pal.text)
    private val keys = LinearLayout(ctx)
    private val del = Glyph(ctx, Glyph.K_BACKSPACE)
    private val dots = Glyph(ctx, Glyph.K_KEYPAD)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private var expanded = true

    init {
        orientation = LinearLayout.VERTICAL
        background = ctx.bgTop(pal.sheet, 26)
        elevation = ctx.dp(10).toFloat()
        setPadding(0, ctx.dp(8), 0, ctx.dp(4))

        numView.gravity = Gravity.CENTER
        numView.isSingleLine = true
        numView.typeface = light
        numView.visibility = View.GONE
        addView(numView, lin(MATCH, ctx.dp(56)))

        keys.orientation = LinearLayout.VERTICAL
        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to ",", "0" to "+", "#" to "")
        )
        for (r in grid) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for ((d, s) in r) {
                row.addView(key(d, s), lin(0, ctx.dp(60), 1f))
            }
            keys.addView(row, lin(MATCH, WRAP))
        }
        addView(keys, lin(MATCH, WRAP))

        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(0, ctx.dp(2), 0, ctx.dp(8))

        val menu = Glyph(ctx, Glyph.K_MENU)
        menu.color = pal.sub
        val leftCell = ctx.iconCell(menu, 24) { openSettings(ctx) }

        dots.color = pal.sub
        del.color = pal.sub
        del.visibility = View.GONE
        val rightCell = FrameLayout(ctx)
        rightCell.background = ctx.ripple(Color.TRANSPARENT, 28, rippleColor = 0x22888888)
        rightCell.addView(dots, FrameLayout.LayoutParams(ctx.dp(24), ctx.dp(24), Gravity.CENTER))
        rightCell.addView(del, FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.CENTER))
        rightCell.setOnClickListener {
            if (sb.isNotEmpty()) {
                sb.deleteCharAt(sb.length - 1)
                update()
            } else {
                toggle()
            }
        }
        rightCell.setOnLongClickListener {
            if (sb.isNotEmpty()) {
                sb.setLength(0)
                update()
                true
            } else {
                false
            }
        }

        val call = ImageView(ctx)
        call.setImageResource(R.drawable.ic_call)
        call.setColorFilter(Color.WHITE)
        call.scaleType = ImageView.ScaleType.CENTER_INSIDE
        call.setPadding(ctx.dp(18), ctx.dp(18), ctx.dp(18), ctx.dp(18))
        call.background = ctx.ripple(XI_GREEN, circle = true, rippleColor = 0x44FFFFFF)
        call.setOnClickListener {
            if (sb.isEmpty()) callLastNumber(ctx) else placeCall(ctx, sb.toString())
        }

        bottom.addView(leftCell, lin(0, ctx.dp(56), 1f))
        bottom.addView(call, lin(ctx.dp(64), ctx.dp(64)))
        bottom.addView(rightCell, lin(0, ctx.dp(56), 1f))
        addView(bottom, lin(MATCH, WRAP))
    }

    private fun key(d: String, sub: String): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.background = ctx.ripple(Color.TRANSPARENT, 30, rippleColor = 0x22888888)
        col.setOnClickListener {
            sb.append(d)
            update()
        }
        if (d == "0") {
            col.setOnLongClickListener {
                sb.append("+")
                update()
                true
            }
        }
        val num = ctx.label(d, 26f, pal.text)
        num.typeface = light
        num.gravity = Gravity.CENTER
        col.addView(num, lin(WRAP, WRAP))
        val letters = ctx.label(if (sub.isEmpty()) " " else sub, 9f, pal.sub)
        letters.letterSpacing = 0.1f
        letters.gravity = Gravity.CENTER
        col.addView(letters, lin(WRAP, WRAP))
        return col
    }

    fun isEmpty(): Boolean = sb.isEmpty()

    private fun toggle() {
        expanded = !expanded
        keys.visibility = if (expanded) View.VISIBLE else View.GONE
    }

    fun setNumber(n: String) {
        sb.setLength(0)
        sb.append(n)
        expanded = true
        keys.visibility = View.VISIBLE
        update()
    }

    private fun update() {
        val has = sb.isNotEmpty()
        numView.text = sb.toString()
        numView.textSize = if (sb.length > 12) 22f else 30f
        numView.visibility = if (has) View.VISIBLE else View.GONE
        del.visibility = if (has) View.VISIBLE else View.GONE
        dots.visibility = if (has) View.GONE else View.VISIBLE
    }
}
