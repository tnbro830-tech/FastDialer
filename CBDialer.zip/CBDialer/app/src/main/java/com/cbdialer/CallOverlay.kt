package com.cbdialer

import android.animation.ObjectAnimator
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Floating UI:
 *  - Incoming: upar chhota card (Answer / Decline)
 *  - Call ke dauran: draggable pill (Mute / Speaker / End + timer)
 * Flags FLAG_NOT_FOCUSABLE + FLAG_NOT_TOUCH_MODAL => game ka focus aur touch kabhi nahi rukta.
 */
class CallOverlay(private val svc: CallService) {
    private val ctx: Context = svc
    private val wm: WindowManager = ctx.getSystemService(WindowManager::class.java)
    private val nm: NotificationManager = ctx.getSystemService(NotificationManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val names = HashMap<String, String>()

    private var ringing: Call? = null
    private var ongoing: Call? = null

    // Overlay ke 2 hisse: wrapper (window me jata hai, shadow ke liye khali jagah) aur uske andar asli card
    private class Wrap(c: Context) : FrameLayout(c) {
        var touchState: ((Boolean) -> Unit)? = null
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> touchState?.invoke(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touchState?.invoke(false)
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    private val restAlpha = 0.5f // call uthane ke baad pill ki opacity (chhodne par). Pakadte hi 1.0
    private val vibes = ArrayList<ObjectAnimator>()

    private var inView: Wrap? = null
    private var inCard: LinearLayout? = null
    private lateinit var inName: TextView
    private lateinit var inSub: TextView

    private var onView: Wrap? = null
    private var onCard: LinearLayout? = null
    private lateinit var onName: TextView
    private lateinit var onTime: TextView
    private class Tog(val box: FrameLayout, val g: Glyph)

    private lateinit var btnMute: Tog
    private lateinit var btnSpeaker: Tog
    private var pillX = ctx.dp(12)
    private var pillY = ctx.dp(140)

    private val tick = object : Runnable {
        override fun run() {
            refreshTimer()
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- main update ----------
    fun update(calls: List<Call>) {
        val live = calls.filter { it.state != Call.STATE_DISCONNECTED }
        ringing = live.firstOrNull { it.state == Call.STATE_RINGING }
        ongoing = live.firstOrNull { it.state != Call.STATE_RINGING }
        if (live.isEmpty()) {
            hide(true)
            return
        }
        if (InCallActivity.visible || InCallActivity.launching()) {
            removeIncoming()
            removeOngoing()
            svc.hideForeground()
            return
        }
        wasLocked = isLocked()
        // Lock screen pe overlay nahi dikhta => ongoing-call notification (status bar me phone icon / green chip,
        // touch karne pe call screen). Overlay permission na ho tab bhi yahi.
        if (wasLocked || !Settings.canDrawOverlays(ctx)) {
            removeIncoming()
            removeOngoing()
            postCallNotification()
            return
        }
        svc.hideForeground()
        val r = ringing
        val o = ongoing
        val hadIncoming = inView != null
        val freshPill = onView == null
        if (r != null) showIncoming(r) else if (!(hadIncoming && o != null)) removeIncoming(true)
        if (o != null) {
            // Call uthai: incoming card hi chhoti hoke pill ban jaye (iOS jaisa morph)
            val morph = r == null && hadIncoming && freshPill
            showOngoing(o, morph)
            if (morph) morphIncomingIntoPill()
        } else {
            removeOngoing(true)
        }
    }

    fun hide(animate: Boolean = false) {
        removeIncoming(animate)
        removeOngoing(animate)
        svc.hideForeground()
    }

    private var wasLocked = false

    private fun isLocked(): Boolean = try {
        ctx.getSystemService(KeyguardManager::class.java).isKeyguardLocked
    } catch (_: Exception) {
        false
    }

    /** CallService har second bulata hai: phone lock/unlock hua to UI badal do */
    fun checkLock(calls: List<Call>) {
        if (isLocked() != wasLocked) update(calls)
    }

    // ---------- helpers ----------
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    )

    private fun numberOf(call: Call): String =
        call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown"

    private fun nameFor(number: String): String? {
        if (number == "Unknown") return null
        names[number]?.let { return it.ifEmpty { null } }
        var name = ""
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" }
        } catch (_: Exception) {
        }
        names[number] = name
        return name.ifEmpty { null }
    }

    /** Saved contact name, warna network se aaya naam (jaise default dialer me dikhta hai), warna null */
    private fun displayNameFor(call: Call): String? = nameFor(numberOf(call)) ?: networkName(call)

    private fun initial(s: String): String = s.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"

    private fun iconBtn(res: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(ctx)
        v.setImageResource(res)
        v.scaleType = ImageView.ScaleType.CENTER_INSIDE
        v.setPadding(ctx.dp(9), ctx.dp(9), ctx.dp(9), ctx.dp(9))
        v.setOnClickListener { onClick() }
        return v
    }

    /** Gol button with handset: rotate 0 = answer (hara), 135 = decline/end (laal) */
    private fun circleBtn(color: Int, rotateDeg: Float, onClick: () -> Unit): ImageView {
        val v = iconBtn(R.drawable.ic_call, onClick)
        v.setColorFilter(Color.WHITE)
        v.rotation = rotateDeg
        v.setPadding(ctx.dp(11), ctx.dp(11), ctx.dp(11), ctx.dp(11))
        v.background = ctx.ripple(color, circle = true, rippleColor = 0x44FFFFFF)
        return v
    }

    /** Drag a floating window with your finger; a plain tap runs onTap */
    private fun makeDraggable(
        v: View,
        root: View,
        p: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        onMoved: (Int, Int) -> Unit = { _, _ -> }
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = ctx.dp(8)
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        p.x = startX + dx.toInt()
                        p.y = startY + dy.toInt()
                        onMoved(p.x, p.y)
                        try {
                            wm.updateViewLayout(root, p)
                        } catch (_: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                }
            }
            true
        }
    }

    // ---------- animations / glass helpers ----------
    private val restFade = Runnable {
        onView?.animate()?.alpha(restAlpha)?.setDuration(300)?.start()
    }

    private fun whenLaidOut(v: View, run: () -> Unit) {
        v.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                val vto = v.viewTreeObserver
                if (vto.isAlive) vto.removeOnPreDrawListener(this)
                run()
                return true
            }
        })
    }

    /** Shadow (depth) ke liye round outline: translucent glass me default outline nahi banta */
    private fun shadowOutline(v: View, radiusPx: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
                outline.alpha = 0.9f
            }
        }
    }

    private fun wrapper(card: View, cardW: Int): Wrap {
        val w = Wrap(ctx)
        w.clipChildren = false
        w.clipToPadding = false
        w.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(12), ctx.dp(18))
        w.addView(card, FrameLayout.LayoutParams(cardW, WRAP))
        return w
    }

    /** Call aane par: upar se halka sa pop hoke aata hai (thoda overshoot ke saath, iOS banner jaisa) */
    private fun popEnter(w: View) {
        w.alpha = 0f
        w.scaleX = 0.86f
        w.scaleY = 0.86f
        w.translationY = -ctx.dp(16).toFloat()
        whenLaidOut(w) {
            w.pivotX = w.width / 2f
            w.pivotY = 0f
            w.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(480).setInterpolator(OvershootInterpolator(1.25f)).start()
        }
    }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }

    private fun fadeOutAndRemove(w: View) {
        w.pivotX = w.width / 2f
        w.pivotY = 0f
        w.animate().alpha(0f).translationY(-ctx.dp(14).toFloat()).scaleX(0.92f).scaleY(0.92f)
            .setDuration(220).setInterpolator(DecelerateInterpolator()).withEndAction { safeRemove(w) }.start()
    }

    private fun stopVibes() {
        for (a in vibes) a.cancel()
        vibes.clear()
    }

    // ---------- incoming card ----------
    private fun showIncoming(call: Call) {
        val number = numberOf(call)
        val name = displayNameFor(call)
        if (inView == null) buildIncoming()
        inName.text = name ?: number
        inSub.text = if (name != null && number != "Unknown") "$number \u2022 Incoming call" else "Incoming call"
    }

    private fun buildIncoming() {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = ctx.glass(0xFF1E3F36.toInt(), 28)
        card.setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(14))
        card.elevation = ctx.dp(12).toFloat()
        shadowOutline(card, ctx.dp(28).toFloat())

        // Decline: sabse left kone me
        val decline = circleBtn(XI_RED, 135f) { ringing?.reject(false, null) }
        card.addView(decline, lin(ctx.dp(52), ctx.dp(52)))

        // Beech me naam + number (dono buttons ke beech zyada gap)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(ctx.dp(20), 0, ctx.dp(20), 0)
        inName = ctx.label("", 17f, Color.WHITE, true)
        inName.gravity = Gravity.CENTER
        inName.isSingleLine = true
        inName.ellipsize = TextUtils.TruncateAt.END
        inSub = ctx.label("", 13f, 0xFFB9C4C0.toInt())
        inSub.gravity = Gravity.CENTER
        inSub.isSingleLine = true
        inSub.ellipsize = TextUtils.TruncateAt.END
        col.addView(inName, lin(MATCH, WRAP))
        val sp = lin(MATCH, WRAP)
        sp.topMargin = ctx.dp(3)
        col.addView(inSub, sp)
        card.addView(col, lin(0, WRAP, 1f))

        // Answer: sabse right kone me
        val answer = circleBtn(XI_GREEN, 0f) { ringing?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        card.addView(answer, lin(ctx.dp(52), ctx.dp(52)))

        val full = minOf(ctx.resources.displayMetrics.widthPixels, ctx.dp(444))
        val cardW = full - ctx.dp(24)
        val wrap = wrapper(card, cardW)
        val p = params(full, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = ctx.dp(4)
        makeDraggable(card, wrap, p, onTap = { InCallActivity.open(ctx) })
        popEnter(wrap)
        try {
            wm.addView(wrap, p)
            inView = wrap
            inCard = card
            // green / red button halka vibrate hote rehte hain
            vibes.add(startVibrate(decline, ctx.dp(3).toFloat(), 300L))
            vibes.add(startVibrate(answer, ctx.dp(3).toFloat(), 420L))
        } catch (e: Exception) {
            inView = null
            inCard = null
            postCallNotification()
        }
    }

    private fun removeIncoming(animate: Boolean = false) {
        val w = inView ?: return
        inView = null
        inCard = null
        stopVibes()
        if (animate) fadeOutAndRemove(w) else safeRemove(w)
    }

    // ---------- ongoing pill ----------
    private fun showOngoing(call: Call, morph: Boolean = false) {
        val number = numberOf(call)
        if (onView == null) buildOngoing(morph)
        onName.text = displayNameFor(call) ?: number
        refreshTimer()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
    }

    /** Incoming card shrink hoke pill ban jata hai, pill halka overshoot ke saath apni jagah set hoti hai */
    private fun morphIncomingIntoPill() {
        val oldW = inView
        val oldCard = inCard
        val pill = onView
        val pillCard = onCard
        inView = null
        inCard = null
        stopVibes()
        if (oldW == null || oldCard == null || pill == null || pillCard == null) {
            if (oldW != null) safeRemove(oldW)
            return
        }
        pill.alpha = 0f
        pill.scaleX = 0.84f
        pill.scaleY = 0.84f
        whenLaidOut(pill) {
            val cw = oldCard.width.toFloat().coerceAtLeast(1f)
            val ch = oldCard.height.toFloat().coerceAtLeast(1f)
            val pw = pillCard.width.toFloat().coerceAtLeast(1f)
            val ph = pillCard.height.toFloat().coerceAtLeast(1f)
            oldCard.pivotX = cw / 2f
            oldCard.pivotY = 0f
            oldCard.animate().scaleX(pw / cw).scaleY(ph / ch).alpha(0f)
                .setDuration(340).setInterpolator(DecelerateInterpolator(1.7f))
                .withEndAction { safeRemove(oldW) }.start()
            pill.pivotX = pill.width / 2f
            pill.pivotY = 0f
            pill.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(70).setDuration(460).setInterpolator(OvershootInterpolator(1.15f)).start()
            ui.removeCallbacks(restFade)
            ui.postDelayed(restFade, 2000)
        }
    }

    private fun toggleBtn(kind: Int, onClick: () -> Unit): Tog {
        val g = Glyph(ctx, kind)
        g.color = Color.WHITE
        val f = FrameLayout(ctx)
        f.addView(g, FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        return Tog(f, g)
    }

    private fun styleToggle(t: Tog, on: Boolean) {
        t.g.color = if (on) Color.BLACK else Color.WHITE
        t.box.background = if (on) {
            ctx.ripple(Color.WHITE, circle = true, rippleColor = 0x33888888)
        } else {
            ctx.glassCircle(Color.WHITE, 0x30)
        }
    }

    private fun buildOngoing(morph: Boolean) {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = ctx.glass(0xFF1A382F.toInt(), 34)
        card.setPadding(ctx.dp(20), ctx.dp(9), ctx.dp(9), ctx.dp(9))
        card.elevation = ctx.dp(10).toFloat()
        shadowOutline(card, ctx.dp(34).toFloat())

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        onName = ctx.label("", 15f, Color.WHITE, true)
        onName.isSingleLine = true
        onName.ellipsize = TextUtils.TruncateAt.END
        onName.maxWidth = ctx.dp(104)
        onTime = ctx.label("", 14f, Color.WHITE)
        col.addView(onName)
        val st = lin(WRAP, WRAP)
        st.topMargin = ctx.dp(2)
        col.addView(onTime, st)
        val lc = lin(WRAP, WRAP)
        lc.rightMargin = ctx.dp(12)
        card.addView(col, lc)

        btnMute = toggleBtn(Glyph.K_MIC) {
            svc.setMuted(!(svc.callAudioState?.isMuted ?: false))
        }
        btnSpeaker = toggleBtn(Glyph.K_SPEAKER) {
            val on = svc.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
            svc.setAudioRoute(if (on) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
        }
        val end = circleBtn(XI_RED, 135f) { ongoing?.disconnect() }
        styleToggle(btnMute, false)
        styleToggle(btnSpeaker, false)

        for (b in listOf<View>(btnMute.box, btnSpeaker.box, end)) {
            val l = lin(ctx.dp(42), ctx.dp(42))
            l.rightMargin = ctx.dp(7)
            card.addView(b, l)
        }

        val wrap = wrapper(card, WRAP)
        val p = params(WRAP, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = 0
        p.y = ctx.dp(4)

        // pakadte hi opacity full, chhodte hi ~50%
        wrap.touchState = { down ->
            ui.removeCallbacks(restFade)
            if (down) {
                wrap.animate().alpha(1f).setDuration(120).start()
            } else {
                ui.postDelayed(restFade, 350)
            }
        }

        makeDraggable(col, wrap, p, onTap = { InCallActivity.open(ctx) }) { x, y ->
            pillX = x
            pillY = y
        }
        makeDraggable(card, wrap, p, onTap = { InCallActivity.open(ctx) }) { x, y ->
            pillX = x
            pillY = y
        }

        if (morph) {
            wrap.alpha = 0f
        } else {
            popEnter(wrap)
            ui.removeCallbacks(restFade)
            ui.postDelayed(restFade, 2000)
        }

        try {
            wm.addView(wrap, p)
            onView = wrap
            onCard = card
            svc.callAudioState?.let { audioChanged(it) }
        } catch (e: Exception) {
            onView = null
            onCard = null
            postCallNotification()
        }
    }

    private fun removeOngoing(animate: Boolean = false) {
        ui.removeCallbacks(restFade)
        ui.removeCallbacks(tick)
        val w = onView ?: return
        onView = null
        onCard = null
        if (animate) fadeOutAndRemove(w) else safeRemove(w)
    }

    fun audioChanged(a: CallAudioState) {
        if (onView == null) return
        btnMute.g.kind = if (a.isMuted) Glyph.K_MIC_OFF else Glyph.K_MIC
        styleToggle(btnMute, a.isMuted)
        styleToggle(btnSpeaker, a.route == CallAudioState.ROUTE_SPEAKER)
    }

    private fun refreshTimer() {
        if (onView == null) return
        val c = ongoing ?: return
        onTime.text = when (c.state) {
            Call.STATE_ACTIVE -> elapsed(c)
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            else -> "…"
        }
    }

    private fun elapsed(c: Call): String {
        val t = c.details.connectTimeMillis
        if (t <= 0) return "00:00"
        val s = ((System.currentTimeMillis() - t) / 1000).toInt().coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    // ---------- notification: lock screen pe ya overlay permission na ho tab ----------
    // Ongoing call me status bar me phone icon aata hai (Android 12+ pe green call chip + timer),
    // us pe touch karne se call screen khul jati hai.
    private fun ensureChannels() {
        val ch = NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
        val on = NotificationChannel("ongoing_call", "Ongoing call", NotificationManager.IMPORTANCE_LOW)
        on.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(on)
    }

    private fun actionPi(act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, CallActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun postCallNotification() {
        val ring = ringing
        val on = ongoing
        val c = ring ?: on ?: return
        val who = displayNameFor(c) ?: numberOf(c)
        ensureChannels()
        val channel = if (ring != null) "calls" else "ongoing_call"
        val open = PendingIntent.getActivity(
            ctx, 11, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val connected = if (ring == null && on != null && on.state == Call.STATE_ACTIVE) {
            on.details.connectTimeMillis
        } else {
            0L
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val person = Person.Builder().setName(who).setImportant(true).build()
                val style = if (ring != null) {
                    Notification.CallStyle.forIncomingCall(person, actionPi("decline"), actionPi("answer"))
                } else {
                    Notification.CallStyle.forOngoingCall(person, actionPi("end"))
                }
                val nb = Notification.Builder(ctx, channel)
                    .setSmallIcon(R.drawable.ic_call)
                    .setContentIntent(open)
                    .setCategory(Notification.CATEGORY_CALL)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setStyle(style)
                if (connected > 0) {
                    nb.setUsesChronometer(true)
                    nb.setWhen(connected)
                }
                svc.showForeground(nb.build())
                return
            } catch (_: Exception) {
                // purane Android / koi dikkat: neeche wali simple notification
            }
        }

        val b = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(who)
            .setContentText(if (ring != null) "Incoming call" else "Ongoing call")
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (ring != null) {
            b.addAction(action("Answer", "answer"))
            b.addAction(action("Decline", "decline"))
        } else {
            if (connected > 0) {
                b.setUsesChronometer(true)
                b.setWhen(connected)
            }
            b.addAction(action("End", "end"))
        }
        svc.showForeground(b.build())
    }

    private fun action(title: String, act: String): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(ctx, R.drawable.ic_call), title, actionPi(act)).build()
}
