package com.cbdialer

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentResolver
import android.graphics.Color
import android.os.Bundle
import android.provider.CallLog
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Recents me row ke side wale arrow ko dabane par khulne wali screen:
 * bada avatar, naam (number se bada), Call / Message / WhatsApp / Add contact buttons,
 * us number ki poori call history aur Block / Delete.
 */
class ContactActivity : Activity() {
    private lateinit var pl: Pal
    private lateinit var historyBox: LinearLayout
    private var number = ""
    private var name: String? = null
    private var ids: LongArray = LongArray(0)
    private val foundIds = ArrayList<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        number = intent.getStringExtra("number") ?: ""
        name = intent.getStringExtra("name")
        ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
        pl = palette()
        window.statusBarColor = pl.bg
        window.navigationBarColor = pl.bg
        window.decorView.systemUiVisibility = if (pl.dark) {
            0
        } else {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pl.bg)

        // top bar: back
        val bar = FrameLayout(this)
        val back = Glyph(this, Glyph.K_CHEVRON)
        back.color = pl.text
        back.rotation = 180f
        val backCell = iconCell(back, 22) { finish() }
        val bl = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        bl.leftMargin = dp(8)
        bar.addView(backCell, bl)
        root.addView(bar, lin(MATCH, dp(52)))

        val sv = ScrollView(this)
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.gravity = Gravity.CENTER_HORIZONTAL
        body.setPadding(dp(16), 0, dp(16), dp(24))
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(sv, lin(MATCH, 0, 1f))
        setContentView(root)

        val shown = name ?: number.ifBlank { "Unknown" }
        val stage = ArrayList<View>()

        // avatar
        val avatar = FrameLayout(this)
        val ch = shown.firstOrNull { it.isLetter() }
        if (ch != null) {
            avatar.background = bg(AV_COLORS[(shown.hashCode() and 0x7fffffff) % AV_COLORS.size], circle = true)
            val ini = label(ch.toString().uppercase(), 40f, Color.WHITE, true)
            ini.gravity = Gravity.CENTER
            avatar.addView(ini, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            avatar.background = bg(pl.avatar, circle = true)
            val pg = Glyph(this, Glyph.K_PERSON_FILL)
            pg.color = if (pl.dark) 0xFFB0B0B5.toInt() else Color.WHITE
            avatar.addView(pg, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        }
        val al = lin(dp(96), dp(96))
        al.gravity = Gravity.CENTER_HORIZONTAL
        al.topMargin = dp(4)
        body.addView(avatar, al)
        stage.add(avatar)

        // naam bada, number chhota
        val nameTv = label(shown, 26f, pl.text, true)
        nameTv.gravity = Gravity.CENTER
        nameTv.isSingleLine = true
        nameTv.ellipsize = android.text.TextUtils.TruncateAt.END
        val nl = lin(MATCH, WRAP)
        nl.topMargin = dp(16)
        body.addView(nameTv, nl)
        stage.add(nameTv)
        if (name != null && number.isNotBlank()) {
            val numTv = label(number, 15f, pl.sub)
            numTv.gravity = Gravity.CENTER
            val ul = lin(MATCH, WRAP)
            ul.topMargin = dp(6)
            body.addView(numTv, ul)
            stage.add(numTv)
        }

        // action buttons
        if (number.isNotBlank()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val callIcon = ImageView(this)
            callIcon.setImageResource(R.drawable.ic_call)
            callIcon.setColorFilter(Color.WHITE)
            val msgIcon = Glyph(this, Glyph.K_CHAT)
            msgIcon.color = pl.text
            val waIcon = Glyph(this, Glyph.K_BUBBLE)
            waIcon.color = XI_GREEN
            val addIcon = Glyph(this, Glyph.K_ADD_PERSON)
            addIcon.color = pl.text
            row.addView(action(callIcon, "Call", XI_GREEN) { placeCall(this, number) }, lin(0, WRAP, 1f))
            row.addView(action(msgIcon, "Message", pl.fill) { openSms(this, number) }, lin(0, WRAP, 1f))
            row.addView(action(waIcon, "WhatsApp", pl.fill) { openWhatsApp(this, number) }, lin(0, WRAP, 1f))
            row.addView(action(addIcon, "Add contact", pl.fill) { addContact(this, number, name) }, lin(0, WRAP, 1f))
            val rl = lin(MATCH, WRAP)
            rl.topMargin = dp(24)
            body.addView(row, rl)
            stage.add(row)
        }

        // history
        val ht = label("RECENT CALLS", 12f, pl.sub, true)
        ht.setPadding(dp(8), 0, 0, 0)
        val htl = lin(MATCH, WRAP)
        htl.topMargin = dp(28)
        htl.bottomMargin = dp(8)
        body.addView(ht, htl)
        stage.add(ht)

        historyBox = LinearLayout(this)
        historyBox.orientation = LinearLayout.VERTICAL
        historyBox.background = bg(pl.fill, 18)
        body.addView(historyBox, lin(MATCH, WRAP))
        stage.add(historyBox)

        // block / delete
        val danger = LinearLayout(this)
        danger.orientation = LinearLayout.VERTICAL
        danger.background = bg(pl.fill, 18)
        if (number.isNotBlank()) {
            danger.addView(dangerRow("Block number", Glyph.K_BLOCK) {
                Prefs.addBlocked(this, number)
                Toast.makeText(this, "Number blocked", Toast.LENGTH_SHORT).show()
            }, lin(MATCH, dp(54)))
        }
        danger.addView(dangerRow("Delete call history", Glyph.K_TRASH) { confirmDeleteAll() }, lin(MATCH, dp(54)))
        val dl = lin(MATCH, WRAP)
        dl.topMargin = dp(20)
        body.addView(danger, dl)
        stage.add(danger)

        for ((i, v) in stage.withIndex()) v.popIn(60L + i * 55L, 22f, 420L)

        loadHistory()
    }

    private fun action(icon: View, text: String, bgColor: Int, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val c = FrameLayout(this)
        c.background = ripple(bgColor, circle = true, rippleColor = 0x33888888)
        c.addView(icon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        c.setOnClickListener { onClick() }
        box.addView(c, lin(dp(58), dp(58)))
        val t = label(text, 12f, pl.sub)
        t.gravity = Gravity.CENTER
        val tl = lin(WRAP, WRAP)
        tl.topMargin = dp(8)
        box.addView(t, tl)
        return box
    }

    private fun dangerRow(text: String, icon: Int, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), 0, dp(18), 0)
        row.background = ripple(Color.TRANSPARENT, 18, rippleColor = 0x22888888)
        val g = Glyph(this, icon)
        g.color = XI_RED
        row.addView(g, lin(dp(22), dp(22)))
        val t = label(text, 16f, XI_RED)
        val tl = lin(WRAP, WRAP)
        tl.leftMargin = dp(14)
        row.addView(t, tl)
        row.setOnClickListener { onClick() }
        return row
    }

    private fun confirmDeleteAll() {
        try {
            AlertDialog.Builder(this)
                .setTitle("Delete call history")
                .setMessage("Remove all calls of this number from recents?")
                .setPositiveButton("Delete") { _, _ ->
                    val all = if (foundIds.isNotEmpty()) foundIds.toList() else ids.toList()
                    if (deleteCallIds(this, all)) {
                        finish()
                    } else {
                        Toast.makeText(this, "Could not delete (allow call log permission)", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (_: Exception) {
        }
    }

    private class H(val type: Int, val date: Long, val dur: Long)

    private fun loadHistory() {
        Thread {
            val list = ArrayList<H>()
            val found = ArrayList<Long>()
            try {
                val args = Bundle()
                var ok = true
                if (number.isNotBlank()) {
                    args.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, CallLog.Calls.NUMBER + " = ?")
                    args.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf(number))
                } else if (ids.isNotEmpty()) {
                    args.putString(
                        ContentResolver.QUERY_ARG_SQL_SELECTION,
                        CallLog.Calls._ID + " IN (" + ids.joinToString(",") + ")"
                    )
                } else {
                    ok = false
                }
                if (ok) {
                    args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
                    args.putInt(ContentResolver.QUERY_ARG_LIMIT, 60)
                    val proj = arrayOf(CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls._ID)
                    contentResolver.query(CallLog.Calls.CONTENT_URI, proj, args, null)?.use { c ->
                        while (c.moveToNext()) {
                            list.add(H(c.getInt(0), c.getLong(1), c.getLong(2)))
                            found.add(c.getLong(3))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                foundIds.clear()
                foundIds.addAll(found)
                fillHistory(list)
            }
        }.start()
    }

    private fun fillHistory(list: List<H>) {
        historyBox.removeAllViews()
        if (list.isEmpty()) {
            val e = label("No calls", 14f, pl.sub)
            e.setPadding(dp(18), dp(16), dp(18), dp(16))
            historyBox.addView(e, lin(MATCH, WRAP))
            return
        }
        for ((i, h) in list.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(18), dp(12), dp(18), dp(12))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val missed = h.type == CallLog.Calls.MISSED_TYPE
            val t = label(callTypeText(h.type).ifEmpty { "Call" }, 15f, if (missed) XI_RED else pl.text, true)
            val whenText = DateUtils.formatDateTime(
                this, h.date,
                DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_ALL
            )
            val d = label(whenText, 12f, pl.sub)
            col.addView(t)
            val dl = lin(WRAP, WRAP)
            dl.topMargin = dp(3)
            col.addView(d, dl)
            row.addView(col, lin(0, WRAP, 1f))

            val dur: TextView = label(durText(h.dur), 13f, pl.sub)
            row.addView(dur, lin(WRAP, WRAP))
            historyBox.addView(row, lin(MATCH, WRAP))

            if (i < list.size - 1) {
                val line = View(this)
                line.setBackgroundColor(0x22888888)
                val ll = lin(MATCH, 1)
                ll.leftMargin = dp(18)
                historyBox.addView(line, ll)
            }
        }
    }
}
