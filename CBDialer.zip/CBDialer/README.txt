CB DIALER (v1.0) - ye NAYI ALAG APP hai, Fast Dialer ka update nahi.
- App id: com.cbdialer.app  => purani Fast Dialer / Fast Dialer 2 ke saath saath install hoti hai, kuch overwrite nahi hota.
- Naam: "CB Dialer", icon ka rang purple. Alag keystore (app/cbdialer.keystore).
- Naye app ko default Phone app banana padega aur permissions dobara deni padengi (call log delete ke liye "Call log" permission bhi).

GITHUB se build (asan tareeka):
1. GitHub pe NAYI repo banao (jaise CBDialer).
2. Is folder ke ANDAR ki saari files repo me upload karo (settings.gradle.kts, app/, .github/ sab repo ke root me dikhna chahiye).
   Dhyan: ".github" folder bhi upload hona chahiye, warna build start nahi hoga.
3. Actions tab > "Build APK" chalega (ya Run workflow). Khatam hone par Artifacts me CBDialer-APK download karo.

AndroidIDE se build: Open existing project > is folder ko kholo > assembleDebug.

--- Is version me kya naya hai ---
- Naam CB Dialer.
- Incoming floating card: halka glass effect (bina blur ke, opacity almost full => lag nahi) + depth (shadow, chamakti border).
  Aate waqt smooth pop animation. Green / red button me gap zyada + vibrate animation.
- Call uthane par incoming card chhoti hoke pill ban jati hai (iOS jaisa smooth morph).
- Pill pehle se thodi badi. Chhodne par opacity ~50%, pakadte / drag karte waqt 100%.
  (Opacity badalni ho to CallOverlay.kt me restAlpha = 0.5f)
- Lock screen pe call screen: entrance animation, avatar ke peeche pulse rings, green/red vibrate, gap zyada,
  call uthane par buttons smooth aate hain.
- Recents list scroll karne par dial pad chhup jata hai, ab wapas SIRF kone ke 3x3 dots button se aata hai.
- "CNAP" (kisi bhi form me) / Unknown / Private jaise label ab naam ki jagah kahin nahi dikhte (call screen, floating card, recents).
- Dial pad khali ho to green button dabane par sabse nayi call (aayi ho ya milai ho) ka number lag jata hai.
- Recents me side ke arrow pe tap => us number ka poora interface (bada naam, chhota number, Call / Message / WhatsApp /
  Add contact, call history, Block, Delete history).
- Recents me row pe long press => Add contact / Delete / Send WhatsApp message / Message.
