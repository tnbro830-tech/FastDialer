FAST DIALER - floating call UI wala lightweight dialer

PHONE PE BUILD (AndroidIDE app se):
1. AndroidIDE install karo (github.com/AndroidIDEOfficial/AndroidIDE releases, arm64-v8a APK).
2. Pehli baar kholo: storage permission do aur setup/packages install hone do (internet chahiye).
3. MT Manager se FastDialer.zip ko extract karo (FastDialer folder banega).
4. AndroidIDE > Open existing project > FastDialer folder (jisme settings.gradle.kts hai).
5. Gradle sync poora hone do (pehli baar internet se files download hongi, 10-20 min).
6. Build > Run / assembleDebug. APK milega: app/build/outputs/apk/debug/app-debug.apk

APK install ke baad app kholo, upar blue banner ke 3 steps follow karo:
permissions -> overlay permission -> default Phone app.
Settings > Battery > Fast Dialer > Unrestricted bhi kar dena.

GITHUB se build karna ho to .github/workflows/build.yml dekho.
