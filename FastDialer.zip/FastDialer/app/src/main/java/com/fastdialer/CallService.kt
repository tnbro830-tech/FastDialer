package com.fastdialer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

/** System jab call deta hai (incoming/outgoing) to ye service chalti hai. Full-screen nahi kholti, sirf floating overlay. */
class CallService : InCallService() {
    companion object {
        @Volatile
        var instance: CallService? = null
    }

    private val calls = ArrayList<Call>()
    private lateinit var overlay: CallOverlay

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            overlay.update(calls)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            overlay.update(calls)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        overlay = CallOverlay(this)
    }

    override fun onDestroy() {
        overlay.hide()
        instance = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        calls.add(call)
        call.registerCallback(cb)
        overlay.update(calls)
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        calls.remove(call)
        overlay.update(calls)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        overlay.audioChanged(audioState)
    }

    fun ringing(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING }
    fun ongoing(): Call? =
        calls.firstOrNull { it.state != Call.STATE_RINGING && it.state != Call.STATE_DISCONNECTED }
}

/** Notification buttons (agar overlay permission na ho to fallback) */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val s = CallService.instance ?: return
        when (intent.action) {
            "answer" -> s.ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY)
            "decline" -> s.ringing()?.reject(false, null)
            "end" -> s.ongoing()?.disconnect()
        }
    }
}
