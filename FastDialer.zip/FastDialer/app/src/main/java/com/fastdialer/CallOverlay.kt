package com.fastdialer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Floating UI:
 *  - Incoming: upar chhota card (Answer / Decline)
 *  - Call ke dauran: draggable pill (Mute / Speaker / End + timer)
 * Flags FLAG_NOT_FOCUSABLE + FLAG_NOT_TOUCH_MODAL => game ka focus aur touch kabhi nahi rukta.
 */
class CallOverlay(private val svc: CallService) {
    private val ctx: Context = svc
    private val wm: WindowManager = ctx.getSystemService(WindowManager::class.java)
    private val nm: NotificationManager = ctx.getSystemService(NotificationManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val names = HashMap<String, String>()

    private var ringing: Call? = null
    private var ongoing: Call? = null

    private var inView: LinearLayout? = null
    private lateinit var inName: TextView
    private lateinit var inSub: TextView
    private lateinit var inAvatar: TextView

    private var onView: LinearLayout? = null
    private lateinit var onName: TextView
    private lateinit var onTime: TextView
    private lateinit var btnMute: TextView
    private lateinit var btnSpeaker: TextView
    private var pillX = ctx.dp(12)
    private var pillY = ctx.dp(140)

    private val tick = object : Runnable {
        override fun run() {
            refreshTimer()
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- main update ----------
    fun update(calls: List<Call>) {
        val live = calls.filter { it.state != Call.STATE_DISCONNECTED }
        ringing = live.firstOrNull { it.state == Call.STATE_RINGING }
        ongoing = live.firstOrNull { it.state != Call.STATE_RINGING }
        if (live.isEmpty()) {
            hide()
            return
        }
        if (!Settings.canDrawOverlays(ctx)) {
            removeIncoming()
            removeOngoing()
            notifyFallback()
            return
        }
        nm.cancel(7)
        val r = ringing
        if (r != null) showIncoming(r) else removeIncoming()
        val o = ongoing
        if (o != null) showOngoing(o) else removeOngoing()
    }

    fun hide() {
        removeIncoming()
        removeOngoing()
        nm.cancel(7)
    }

    // ---------- helpers ----------
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    )

    private fun numberOf(call: Call): String =
        call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown"

    private fun nameFor(number: String): String? {
        if (number == "Unknown") return null
        names[number]?.let { return it.ifEmpty { null } }
        var name = ""
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" }
        } catch (_: Exception) {
        }
        names[number] = name
        return name.ifEmpty { null }
    }

    private fun initial(s: String): String = s.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"

    private fun pill(text: String, color: Int, onClick: () -> Unit): TextView {
        val t = ctx.label(text, 15f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.background = ctx.ripple(color, 23, rippleColor = 0x44FFFFFF)
        t.setOnClickListener { onClick() }
        return t
    }

    // ---------- incoming card ----------
    private fun showIncoming(call: Call) {
        val number = numberOf(call)
        val name = nameFor(number)
        if (inView == null) buildIncoming()
        inName.text = name ?: number
        inSub.text = if (name != null) "$number • Incoming call" else "Incoming call"
        inAvatar.text = initial(name ?: number)
    }

    private fun buildIncoming() {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.background = ctx.bg(0xF2202124.toInt(), 22)
        card.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        card.elevation = ctx.dp(8).toFloat()

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        inAvatar = ctx.label("?", 18f, Color.WHITE, true)
        inAvatar.gravity = Gravity.CENTER
        inAvatar.background = ctx.bg(0xFF5F6368.toInt(), circle = true)
        head.addView(inAvatar, lin(ctx.dp(44), ctx.dp(44)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(12), 0, 0, 0)
        inName = ctx.label("", 18f, Color.WHITE, true)
        inName.isSingleLine = true
        inName.ellipsize = TextUtils.TruncateAt.END
        inSub = ctx.label("", 13f, 0xFFBDC1C6.toInt())
        inSub.isSingleLine = true
        col.addView(inName)
        val sp = lin(WRAP, WRAP)
        sp.topMargin = ctx.dp(3)
        col.addView(inSub, sp)
        head.addView(col, lin(0, WRAP, 1f))
        card.addView(head)

        val btns = LinearLayout(ctx)
        btns.orientation = LinearLayout.HORIZONTAL
        val decline = pill("Decline", 0xFFD93025.toInt()) { ringing?.reject(false, null) }
        val answer = pill("Answer", 0xFF1E8E3E.toInt()) { ringing?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        val ld = lin(0, ctx.dp(46), 1f); ld.rightMargin = ctx.dp(6)
        val la = lin(0, ctx.dp(46), 1f); la.leftMargin = ctx.dp(6)
        btns.addView(decline, ld)
        btns.addView(answer, la)
        val lb = lin(MATCH, WRAP)
        lb.topMargin = ctx.dp(14)
        card.addView(btns, lb)

        val w = minOf(ctx.resources.displayMetrics.widthPixels - ctx.dp(24), ctx.dp(420))
        val p = params(w, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = ctx.dp(10)
        try {
            wm.addView(card, p)
            inView = card
        } catch (e: Exception) {
            inView = null
            notifyFallback()
        }
    }

    private fun removeIncoming() {
        inView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        inView = null
    }

    // ---------- ongoing pill ----------
    private fun showOngoing(call: Call) {
        val number = numberOf(call)
        if (onView == null) buildOngoing()
        onName.text = nameFor(number) ?: number
        refreshTimer()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
    }

    private fun small(text: String, onClick: () -> Unit): TextView {
        val t = ctx.label(text, 12f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        return t
    }

    private fun styleToggle(tv: TextView, on: Boolean) {
        tv.setTextColor(if (on) 0xFF202124.toInt() else Color.WHITE)
        tv.background = ctx.ripple(if (on) Color.WHITE else 0xFF3C4043.toInt(), 18, rippleColor = 0x33888888)
    }

    private fun buildOngoing() {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = ctx.bg(0xF2202124.toInt(), 26)
        card.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        card.elevation = ctx.dp(6).toFloat()

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        onName = ctx.label("", 14f, Color.WHITE, true)
        onName.isSingleLine = true
        onName.ellipsize = TextUtils.TruncateAt.END
        onName.maxWidth = ctx.dp(90)
        onTime = ctx.label("", 12f, 0xFF81C995.toInt())
        col.addView(onName)
        val st = lin(WRAP, WRAP)
        st.topMargin = ctx.dp(2)
        col.addView(onTime, st)
        val lc = lin(WRAP, WRAP)
        lc.rightMargin = ctx.dp(10)
        card.addView(col, lc)

        btnMute = small("Mute") {
            svc.setMuted(!(svc.callAudioState?.isMuted ?: false))
        }
        btnSpeaker = small("Spkr") {
            val on = svc.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
            svc.setAudioRoute(if (on) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
        }
        val end = small("End") { ongoing?.disconnect() }
        end.background = ctx.ripple(0xFFD93025.toInt(), 18, rippleColor = 0x44FFFFFF)
        styleToggle(btnMute, false)
        styleToggle(btnSpeaker, false)

        for (b in listOf(btnMute, btnSpeaker, end)) {
            val l = lin(ctx.dp(50), ctx.dp(36))
            l.rightMargin = ctx.dp(6)
            card.addView(b, l)
        }

        val p = params(WRAP, WRAP)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = pillX
        p.y = pillY

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        col.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = p.x; startY = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (e.rawX - downX).toInt()
                    p.y = startY + (e.rawY - downY).toInt()
                    pillX = p.x; pillY = p.y
                    try {
                        wm.updateViewLayout(card, p)
                    } catch (_: Exception) {
                    }
                }
            }
            true
        }

        try {
            wm.addView(card, p)
            onView = card
            svc.callAudioState?.let { audioChanged(it) }
        } catch (e: Exception) {
            onView = null
            notifyFallback()
        }
    }

    private fun removeOngoing() {
        onView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        onView = null
        ui.removeCallbacks(tick)
    }

    fun audioChanged(a: CallAudioState) {
        if (onView == null) return
        styleToggle(btnMute, a.isMuted)
        styleToggle(btnSpeaker, a.route == CallAudioState.ROUTE_SPEAKER)
    }

    private fun refreshTimer() {
        if (onView == null) return
        val c = ongoing ?: return
        onTime.text = when (c.state) {
            Call.STATE_ACTIVE -> elapsed(c)
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            else -> "…"
        }
    }

    private fun elapsed(c: Call): String {
        val t = c.details.connectTimeMillis
        if (t <= 0) return "00:00"
        val s = ((System.currentTimeMillis() - t) / 1000).toInt().coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    // ---------- fallback: overlay permission na ho to notification (taaki call uthane se rah na jaye) ----------
    private fun notifyFallback() {
        val ch = NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
        val ring = ringing
        val on = ongoing
        val c = ring ?: on ?: return
        val number = numberOf(c)
        val b = Notification.Builder(ctx, "calls")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(nameFor(number) ?: number)
            .setContentText(if (ring != null) "Incoming call" else "Ongoing call")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
        if (ring != null) {
            b.addAction(action("Answer", "answer"))
            b.addAction(action("Decline", "decline"))
        } else {
            b.addAction(action("End", "end"))
        }
        nm.notify(7, b.build())
    }

    private fun action(title: String, act: String): Notification.Action {
        val pi = PendingIntent.getBroadcast(
            ctx, act.hashCode(), Intent(ctx, CallActionReceiver::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(
            Icon.createWithResource(ctx, android.R.drawable.sym_action_call), title, pi
        ).build()
    }
}
