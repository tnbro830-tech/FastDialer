package com.fastdialer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

// iOS jaise rang
val IOS_BLUE = 0xFF007AFF.toInt()
val IOS_GREEN = 0xFF34C759.toInt()
val IOS_RED = 0xFFFF3B30.toInt()
val IOS_GRAY = 0xFF8E8E93.toInt()
val IOS_FILL = 0xFFE9E9EB.toInt()
val IOS_SEP = 0xFFE5E5EA.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bg(color: Int, radiusDp: Int = 0, circle: Boolean = false): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    if (circle) d.setShape(GradientDrawable.OVAL) else d.setCornerRadius(dp(radiusDp).toFloat())
    return d
}

fun Context.ripple(
    color: Int, radiusDp: Int = 0, circle: Boolean = false, rippleColor: Int = 0x33000000
): RippleDrawable = RippleDrawable(
    ColorStateList.valueOf(rippleColor), bg(color, radiusDp, circle), bg(Color.WHITE, radiusDp, circle)
)

fun Context.label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    v.setTextColor(color)
    if (bold) v.typeface = Typeface.DEFAULT_BOLD
    v.includeFontPadding = false
    return v
}

fun lin(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

/** iOS tab bar ke icons (Canvas se bane: keypad dots, clock, person) */
class TabIcon(ctx: Context, private val kind: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var iconColor: Int = 0xFF8E8E93.toInt()
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        p.color = iconColor
        p.strokeCap = Paint.Cap.ROUND
        when (kind) {
            0 -> {
                p.style = Paint.Style.FILL
                val gx = s * 0.30f
                val gy = s * 0.24f
                val r = s * 0.075f
                for (i in 0..2) {
                    for (j in 0..3) {
                        canvas.drawCircle(cx + (i - 1) * gx, cy + (j - 1.5f) * gy, r, p)
                    }
                }
            }
            1 -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.09f
                canvas.drawCircle(cx, cy, s * 0.40f, p)
                canvas.drawLine(cx, cy, cx, cy - s * 0.22f, p)
                canvas.drawLine(cx, cy, cx + s * 0.15f, cy + s * 0.09f, p)
            }
            else -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.09f
                canvas.drawCircle(cx, cy - s * 0.17f, s * 0.15f, p)
                val rect = RectF(cx - s * 0.34f, cy + s * 0.02f, cx + s * 0.34f, cy + s * 0.70f)
                canvas.drawArc(rect, 180f, 180f, false, p)
            }
        }
    }
}
