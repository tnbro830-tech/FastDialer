package com.fastdialer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bg(color: Int, radiusDp: Int = 0, circle: Boolean = false): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    if (circle) d.setShape(GradientDrawable.OVAL) else d.setCornerRadius(dp(radiusDp).toFloat())
    return d
}

fun Context.ripple(
    color: Int, radiusDp: Int = 0, circle: Boolean = false, rippleColor: Int = 0x33000000
): RippleDrawable = RippleDrawable(
    ColorStateList.valueOf(rippleColor), bg(color, radiusDp, circle), bg(Color.WHITE, radiusDp, circle)
)

fun Context.label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    v.setTextColor(color)
    if (bold) v.typeface = Typeface.DEFAULT_BOLD
    v.includeFontPadding = false
    return v
}

fun lin(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
