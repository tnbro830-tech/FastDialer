package com.fastdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

fun callNumber(call: Call): String =
    call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown"

fun lookupName(ctx: Context, number: String): String? {
    if (number == "Unknown") return null
    var name: String? = null
    try {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) name = it.getString(0) }
    } catch (_: Exception) {
    }
    return name?.takeIf { it.isNotBlank() }
}

fun callElapsed(c: Call): String {
    val t = c.details.connectTimeMillis
    if (t <= 0) return "00:00"
    val s = ((System.currentTimeMillis() - t) / 1000).toInt().coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%02d:%02d".format(s / 60, s % 60)
}

/** Full-screen call screen (outgoing calls, and incoming calls when the phone is locked) */
class InCallActivity : Activity() {
    companion object {
        @Volatile
        var visible = false

        @Volatile
        private var launchedAt = 0L

        /** True for a moment after we asked Android to open the call screen (so the floating pill doesn't flash first) */
        fun launching(): Boolean = SystemClock.elapsedRealtime() - launchedAt < 1500

        fun open(ctx: Context) {
            launchedAt = SystemClock.elapsedRealtime()
            try {
                val i = Intent(ctx, InCallActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            } catch (_: Exception) {
            }
            // if the screen never shows up, bring the floating pill back
            Handler(Looper.getMainLooper()).postDelayed({ CallService.instance?.refreshUi() }, 1700)
        }
    }

    private class Act(val box: LinearLayout, val circle: FrameLayout, val g: Glyph, val label: TextView) {
        var on: Boolean? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val typed = StringBuilder()
    private var padShown = false
    private var lastNumber = ""
    private var lastName: String? = null

    private lateinit var initial: TextView
    private lateinit var person: Glyph
    private lateinit var avatarBg: FrameLayout
    private lateinit var nameTv: TextView
    private lateinit var subTv: TextView
    private lateinit var stateTv: TextView
    private lateinit var actionGrid: LinearLayout
    private lateinit var padPanel: LinearLayout
    private lateinit var padDigits: TextView
    private lateinit var ringRow: LinearLayout
    private lateinit var endBox: LinearLayout
    private lateinit var mute: Act
    private lateinit var speaker: Act
    private lateinit var hold: Act

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    /** Round handset button: rotate 0 = answer (green), 135 = decline / end (red) */
    private fun handset(color: Int, rot: Float, sizeDp: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(R.drawable.ic_call)
        v.setColorFilter(Color.WHITE)
        v.scaleType = ImageView.ScaleType.CENTER_INSIDE
        v.rotation = rot
        val pad = dp(sizeDp / 4)
        v.setPadding(pad, pad, pad, pad)
        v.background = ripple(color, circle = true, rippleColor = 0x44FFFFFF)
        v.elevation = dp(6).toFloat()
        v.setOnClickListener { onClick() }
        return v
    }

    /** Round translucent action button with the icon inside and the label under it */
    private fun act(kind: Int, text: String, onClick: () -> Unit): Act {
        val g = Glyph(this, kind)
        g.color = Color.WHITE
        val circle = FrameLayout(this)
        circle.background = ripple(0x26FFFFFF, circle = true, rippleColor = 0x33FFFFFF)
        circle.addView(g, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        circle.setOnClickListener { onClick() }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(circle, lin(dp(64), dp(64)))
        val lbl = label(text, 12f, 0xCCFFFFFF.toInt())
        lbl.gravity = Gravity.CENTER
        val lp = lin(WRAP, WRAP)
        lp.topMargin = dp(8)
        box.addView(lbl, lp)
        return Act(box, circle, g, lbl)
    }

    private fun setActive(a: Act, on: Boolean) {
        if (a.on == on) return
        a.on = on
        a.circle.background = ripple(
            if (on) Color.WHITE else 0x26FFFFFF, circle = true, rippleColor = 0x33888888
        )
        a.g.color = if (on) 0xFF0B4D3A.toInt() else Color.WHITE
        a.label.setTextColor(if (on) Color.WHITE else 0xCCFFFFFF.toInt())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = 0xFF0C5640.toInt()
        window.navigationBarColor = 0xFF040A08.toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0C5640.toInt(), 0xFF0A2C23.toInt(), 0xFF040A08.toInt())
        )

        // top row: minimise button
        val topRow = FrameLayout(this)
        val chev = Glyph(this, Glyph.K_CHEVRON)
        chev.color = Color.WHITE
        chev.rotation = 90f
        val minCell = iconCell(chev, 22) { finish() }
        val ml = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        ml.leftMargin = dp(8)
        topRow.addView(minCell, ml)
        root.addView(topRow, lin(MATCH, dp(48)))

        // avatar
        avatarBg = FrameLayout(this)
        initial = label("", 44f, Color.WHITE, true)
        initial.gravity = Gravity.CENTER
        person = Glyph(this, Glyph.K_PERSON_FILL)
        person.color = Color.WHITE
        avatarBg.addView(initial, FrameLayout.LayoutParams(MATCH, MATCH))
        avatarBg.addView(person, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
        val al = lin(dp(112), dp(112))
        al.gravity = Gravity.CENTER_HORIZONTAL
        al.topMargin = dp(28)
        root.addView(avatarBg, al)

        nameTv = label("", 28f, Color.WHITE, true)
        nameTv.gravity = Gravity.CENTER
        nameTv.isSingleLine = true
        nameTv.setPadding(dp(24), 0, dp(24), 0)
        val nl = lin(MATCH, WRAP)
        nl.topMargin = dp(22)
        root.addView(nameTv, nl)

        subTv = label("", 16f, 0xB3FFFFFF.toInt())
        subTv.gravity = Gravity.CENTER
        val sl = lin(MATCH, WRAP)
        sl.topMargin = dp(8)
        root.addView(subTv, sl)

        stateTv = label("", 20f, 0xE6FFFFFF.toInt())
        stateTv.gravity = Gravity.CENTER
        val tl = lin(MATCH, WRAP)
        tl.topMargin = dp(12)
        root.addView(stateTv, tl)

        root.addView(View(this), lin(MATCH, 0, 1f))

        // action buttons (2 rows x 3)
        mute = act(Glyph.K_MIC, "Mute") { toggleMute() }
        val keypadAct = act(Glyph.K_KEYPAD, "Keypad") {
            padShown = true
            refresh()
        }
        speaker = act(Glyph.K_SPEAKER, "Speaker") { toggleSpeaker() }
        hold = act(Glyph.K_PAUSE, "Hold") { toggleHold() }
        val addAct = act(Glyph.K_PLUS, "Add call") { openMain(0) }
        val contactsAct = act(Glyph.K_PERSON_OUT, "Contacts") { openMain(1) }

        actionGrid = LinearLayout(this)
        actionGrid.orientation = LinearLayout.VERTICAL
        actionGrid.setPadding(dp(24), 0, dp(24), 0)
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(mute.box, lin(0, WRAP, 1f))
        row1.addView(keypadAct.box, lin(0, WRAP, 1f))
        row1.addView(speaker.box, lin(0, WRAP, 1f))
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(hold.box, lin(0, WRAP, 1f))
        row2.addView(addAct.box, lin(0, WRAP, 1f))
        row2.addView(contactsAct.box, lin(0, WRAP, 1f))
        actionGrid.addView(row1, lin(MATCH, WRAP))
        val r2l = lin(MATCH, WRAP)
        r2l.topMargin = dp(22)
        actionGrid.addView(row2, r2l)
        root.addView(actionGrid, lin(MATCH, WRAP))

        // DTMF keypad (shown when you tap Keypad)
        padPanel = LinearLayout(this)
        padPanel.orientation = LinearLayout.VERTICAL
        padPanel.gravity = Gravity.CENTER_HORIZONTAL
        padPanel.visibility = View.GONE
        padDigits = label("", 26f, Color.WHITE)
        padDigits.gravity = Gravity.CENTER
        padPanel.addView(padDigits, lin(MATCH, dp(40)))
        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        for (r in grid) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((d, s) in r) {
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.background = ripple(Color.TRANSPARENT, 30, rippleColor = 0x22FFFFFF)
                val dl = label(d, 28f, Color.WHITE)
                dl.gravity = Gravity.CENTER
                val sl2 = label(if (s.isEmpty()) " " else s, 9f, 0xAAFFFFFF.toInt())
                sl2.gravity = Gravity.CENTER
                cell.addView(dl, lin(WRAP, WRAP))
                cell.addView(sl2, lin(WRAP, WRAP))
                cell.setOnClickListener { dtmf(d[0]) }
                row.addView(cell, lin(0, dp(56), 1f))
            }
            padPanel.addView(row, lin(MATCH, WRAP))
        }
        val hide = label("Hide", 15f, 0xFF6FB4FF.toInt(), true)
        hide.setPadding(dp(20), dp(10), dp(20), dp(10))
        hide.setOnClickListener {
            padShown = false
            refresh()
        }
        padPanel.addView(hide, lin(WRAP, WRAP))
        root.addView(padPanel, lin(MATCH, WRAP))

        // incoming: decline + answer
        ringRow = LinearLayout(this)
        ringRow.orientation = LinearLayout.HORIZONTAL
        ringRow.gravity = Gravity.CENTER
        ringRow.addView(
            ringItem(XI_RED, 135f, "Decline") { CallService.instance?.ringing()?.reject(false, null) },
            lin(dp(110), WRAP)
        )
        ringRow.addView(
            ringItem(XI_GREEN, 0f, "Answer") {
                CallService.instance?.ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY)
            },
            lin(dp(110), WRAP)
        )
        val rl = lin(MATCH, WRAP)
        rl.bottomMargin = dp(44)
        root.addView(ringRow, rl)

        // end call button
        endBox = LinearLayout(this)
        endBox.orientation = LinearLayout.VERTICAL
        endBox.gravity = Gravity.CENTER_HORIZONTAL
        endBox.addView(
            handset(XI_RED, 135f, 76) { CallService.instance?.ongoing()?.disconnect() },
            lin(dp(76), dp(76))
        )
        val el = lin(MATCH, WRAP)
        el.topMargin = dp(26)
        el.bottomMargin = dp(40)
        root.addView(endBox, el)

        setContentView(root)
    }

    private fun ringItem(color: Int, rot: Float, text: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(handset(color, rot, 76, onClick), lin(dp(76), dp(76)))
        val lbl = label(text, 13f, 0xCCFFFFFF.toInt())
        lbl.gravity = Gravity.CENTER
        val lp = lin(WRAP, WRAP)
        lp.topMargin = dp(10)
        box.addView(lbl, lp)
        return box
    }

    private fun toggleMute() {
        val s = CallService.instance ?: return
        s.setMuted(!(s.callAudioState?.isMuted ?: false))
    }

    private fun toggleSpeaker() {
        val s = CallService.instance ?: return
        val on = s.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
        s.setAudioRoute(if (on) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
    }

    private fun toggleHold() {
        val c = CallService.instance?.ongoing() ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    private fun dtmf(ch: Char) {
        val c = CallService.instance?.ongoing() ?: return
        c.playDtmfTone(ch)
        typed.append(ch)
        padDigits.text = typed.toString()
        ui.postDelayed({ c.stopDtmfTone() }, 150)
    }

    private fun openMain(tab: Int) {
        val i = Intent(this, MainActivity::class.java)
        i.putExtra("tab", tab)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
        finish()
    }

    private fun refresh() {
        val s = CallService.instance
        val ring = s?.ringing()
        val call = ring ?: s?.ongoing()
        if (s == null || call == null) {
            finish()
            return
        }
        val number = callNumber(call)
        if (number != lastNumber) {
            lastNumber = number
            lastName = lookupName(this, number)
            val who = lastName ?: number
            val ch = who.firstOrNull { it.isLetter() }
            val ring3 = if (ch != null) {
                AV_COLORS[(who.hashCode() and 0x7fffffff) % AV_COLORS.size]
            } else {
                0xFF4F7F70.toInt()
            }
            val d = GradientDrawable()
            d.setShape(GradientDrawable.OVAL)
            d.setColor(ring3)
            d.setStroke(dp(3), 0x40FFFFFF)
            avatarBg.background = d
            if (ch != null) {
                initial.text = ch.toString().uppercase()
                initial.visibility = View.VISIBLE
                person.visibility = View.GONE
            } else {
                initial.visibility = View.GONE
                person.visibility = View.VISIBLE
            }
        }
        val name = lastName
        nameTv.text = name ?: number
        subTv.text = if (name != null) number else ""
        subTv.visibility = if (name != null) View.VISIBLE else View.GONE

        val isRing = ring != null
        stateTv.text = when {
            isRing -> "Incoming call"
            call.state == Call.STATE_HOLDING -> "On hold"
            call.state == Call.STATE_ACTIVE -> callElapsed(call)
            else -> "Calling\u2026"
        }
        ringRow.visibility = if (isRing) View.VISIBLE else View.GONE
        endBox.visibility = if (isRing) View.GONE else View.VISIBLE
        actionGrid.visibility = if (isRing || padShown) View.GONE else View.VISIBLE
        padPanel.visibility = if (!isRing && padShown) View.VISIBLE else View.GONE

        val a = s.callAudioState
        val muted = a?.isMuted ?: false
        val kind = if (muted) Glyph.K_MIC_OFF else Glyph.K_MIC
        if (mute.g.kind != kind) mute.g.kind = kind
        setActive(mute, muted)
        setActive(speaker, a?.route == CallAudioState.ROUTE_SPEAKER)
        setActive(hold, call.state == Call.STATE_HOLDING)
    }

    override fun onResume() {
        super.onResume()
        visible = true
        CallService.instance?.refreshUi()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onPause() {
        visible = false
        ui.removeCallbacks(tick)
        CallService.instance?.refreshUi()
        super.onPause()
    }
}
