package com.fastdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

fun callNumber(call: Call): String =
    call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown"

fun lookupName(ctx: Context, number: String): String? {
    if (number == "Unknown") return null
    var name: String? = null
    try {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) name = it.getString(0) }
    } catch (_: Exception) {
    }
    return name?.takeIf { it.isNotBlank() }
}

fun callElapsed(c: Call): String {
    val t = c.details.connectTimeMillis
    if (t <= 0) return "00:00"
    val s = ((System.currentTimeMillis() - t) / 1000).toInt().coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%02d:%02d".format(s / 60, s % 60)
}

/** Full-screen call screen (outgoing calls, and incoming calls when the phone is locked) */
class InCallActivity : Activity() {
    companion object {
        @Volatile
        var visible = false

        fun open(ctx: Context) {
            try {
                val i = Intent(ctx, InCallActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    private class Act(val box: LinearLayout, val icon: View, val label: TextView)

    private val ui = Handler(Looper.getMainLooper())
    private val typed = StringBuilder()
    private var padShown = false
    private var lastNumber = ""
    private var lastName: String? = null

    private lateinit var initial: TextView
    private lateinit var person: Glyph
    private lateinit var avatarBg: FrameLayout
    private lateinit var nameTv: TextView
    private lateinit var subTv: TextView
    private lateinit var stateTv: TextView
    private lateinit var actionGrid: LinearLayout
    private lateinit var padPanel: LinearLayout
    private lateinit var padDigits: TextView
    private lateinit var ringRow: LinearLayout
    private lateinit var endBtn: ImageView
    private lateinit var mute: Act
    private lateinit var speaker: Act
    private lateinit var hold: Act

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    private fun circle(color: Int, rot: Float, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(android.R.drawable.sym_action_call)
        v.setColorFilter(Color.WHITE)
        v.scaleType = ImageView.ScaleType.CENTER_INSIDE
        v.rotation = rot
        v.setPadding(dp(18), dp(18), dp(18), dp(18))
        v.background = ripple(color, circle = true, rippleColor = 0x44FFFFFF)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun act(icon: View, text: String, onClick: () -> Unit): Act {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(0, dp(14), 0, dp(14))
        box.background = ripple(Color.TRANSPARENT, 16, rippleColor = 0x22FFFFFF)
        val lbl = label(text, 12f, 0xCCFFFFFF.toInt())
        lbl.gravity = Gravity.CENTER
        box.addView(icon, lin(dp(28), dp(28)))
        val lp = lin(WRAP, WRAP)
        lp.topMargin = dp(8)
        box.addView(lbl, lp)
        box.setOnClickListener { onClick() }
        if (icon is Glyph) {
            icon.color = Color.WHITE
        } else if (icon is ImageView) {
            icon.setColorFilter(Color.WHITE)
        }
        return Act(box, icon, lbl)
    }

    private fun setActive(a: Act, on: Boolean) {
        val c = if (on) 0xFF4C9BFF.toInt() else Color.WHITE
        val ic = a.icon
        if (ic is Glyph) {
            ic.color = c
        } else if (ic is ImageView) {
            ic.setColorFilter(c)
        }
        a.label.setTextColor(if (on) c else 0xCCFFFFFF.toInt())
    }

    private fun imgIcon(res: Int): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.scaleType = ImageView.ScaleType.CENTER_INSIDE
        return v
    }

    private fun glyph(kind: Int): Glyph = Glyph(this, kind)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = 0xFF0F5C47.toInt()
        window.navigationBarColor = 0xFF050B09.toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0F5C47.toInt(), 0xFF0A2A22.toInt(), 0xFF050B09.toInt())
        )

        // top row: minimise button
        val topRow = FrameLayout(this)
        val chev = glyph(Glyph.K_CHEVRON)
        chev.color = Color.WHITE
        chev.rotation = 90f
        val minCell = iconCell(chev, 22) { finish() }
        val ml = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        ml.leftMargin = dp(8)
        topRow.addView(minCell, ml)
        root.addView(topRow, lin(MATCH, dp(48)))

        // avatar
        avatarBg = FrameLayout(this)
        initial = label("", 36f, Color.WHITE, true)
        initial.gravity = Gravity.CENTER
        person = glyph(Glyph.K_PERSON_FILL)
        person.color = Color.WHITE
        avatarBg.addView(initial, FrameLayout.LayoutParams(MATCH, MATCH))
        avatarBg.addView(person, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        val al = lin(dp(96), dp(96))
        al.gravity = Gravity.CENTER_HORIZONTAL
        al.topMargin = dp(20)
        root.addView(avatarBg, al)

        nameTv = label("", 24f, Color.WHITE, true)
        nameTv.gravity = Gravity.CENTER
        nameTv.isSingleLine = true
        nameTv.setPadding(dp(24), 0, dp(24), 0)
        val nl = lin(MATCH, WRAP)
        nl.topMargin = dp(18)
        root.addView(nameTv, nl)

        subTv = label("", 15f, 0xCCFFFFFF.toInt())
        subTv.gravity = Gravity.CENTER
        val sl = lin(MATCH, WRAP)
        sl.topMargin = dp(6)
        root.addView(subTv, sl)

        stateTv = label("", 26f, Color.WHITE)
        stateTv.gravity = Gravity.CENTER
        val tl = lin(MATCH, WRAP)
        tl.topMargin = dp(10)
        root.addView(stateTv, tl)

        root.addView(View(this), lin(MATCH, 0, 1f))

        // action buttons (2 rows x 3)
        mute = act(imgIcon(android.R.drawable.ic_btn_speak_now), "Mute") { toggleMute() }
        val keypadAct = act(glyph(Glyph.K_KEYPAD), "Keypad") {
            padShown = true
            refresh()
        }
        speaker = act(imgIcon(android.R.drawable.ic_lock_silent_mode_off), "Speaker") { toggleSpeaker() }
        hold = act(glyph(Glyph.K_PAUSE), "Hold") { toggleHold() }
        val addAct = act(glyph(Glyph.K_PLUS), "Add call") { openMain(0) }
        val contactsAct = act(glyph(Glyph.K_PERSON_OUT), "Contacts") { openMain(1) }

        actionGrid = LinearLayout(this)
        actionGrid.orientation = LinearLayout.VERTICAL
        actionGrid.setPadding(dp(16), 0, dp(16), 0)
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(mute.box, lin(0, WRAP, 1f))
        row1.addView(keypadAct.box, lin(0, WRAP, 1f))
        row1.addView(speaker.box, lin(0, WRAP, 1f))
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(hold.box, lin(0, WRAP, 1f))
        row2.addView(addAct.box, lin(0, WRAP, 1f))
        row2.addView(contactsAct.box, lin(0, WRAP, 1f))
        actionGrid.addView(row1, lin(MATCH, WRAP))
        actionGrid.addView(row2, lin(MATCH, WRAP))
        root.addView(actionGrid, lin(MATCH, WRAP))

        // DTMF keypad (shown when you tap Keypad)
        padPanel = LinearLayout(this)
        padPanel.orientation = LinearLayout.VERTICAL
        padPanel.gravity = Gravity.CENTER_HORIZONTAL
        padPanel.visibility = View.GONE
        padDigits = label("", 26f, Color.WHITE)
        padDigits.gravity = Gravity.CENTER
        padPanel.addView(padDigits, lin(MATCH, dp(40)))
        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        for (r in grid) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((d, s) in r) {
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.background = ripple(Color.TRANSPARENT, 30, rippleColor = 0x22FFFFFF)
                cell.addView(label(d, 28f, Color.WHITE))
                cell.addView(label(if (s.isEmpty()) " " else s, 9f, 0xAAFFFFFF.toInt()))
                cell.setOnClickListener { dtmf(d[0]) }
                row.addView(cell, lin(0, dp(56), 1f))
            }
            padPanel.addView(row, lin(MATCH, WRAP))
        }
        val hide = label("Hide", 15f, 0xFF4C9BFF.toInt(), true)
        hide.setPadding(dp(20), dp(10), dp(20), dp(10))
        hide.setOnClickListener {
            padShown = false
            refresh()
        }
        padPanel.addView(hide, lin(WRAP, WRAP))
        root.addView(padPanel, lin(MATCH, WRAP))

        // incoming: decline + answer
        ringRow = LinearLayout(this)
        ringRow.orientation = LinearLayout.HORIZONTAL
        ringRow.gravity = Gravity.CENTER
        val decline = circle(XI_RED, 135f) { CallService.instance?.ringing()?.reject(false, null) }
        val answer = circle(XI_GREEN, 0f) {
            CallService.instance?.ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }
        val dl = lin(dp(72), dp(72))
        dl.rightMargin = dp(56)
        ringRow.addView(decline, dl)
        ringRow.addView(answer, lin(dp(72), dp(72)))
        val rl = lin(MATCH, WRAP)
        rl.bottomMargin = dp(40)
        root.addView(ringRow, rl)

        // end call button
        endBtn = circle(XI_RED, 135f) { CallService.instance?.ongoing()?.disconnect() }
        val el = lin(dp(72), dp(72))
        el.gravity = Gravity.CENTER_HORIZONTAL
        el.topMargin = dp(8)
        el.bottomMargin = dp(36)
        root.addView(endBtn, el)

        setContentView(root)
    }

    private fun toggleMute() {
        val s = CallService.instance ?: return
        s.setMuted(!(s.callAudioState?.isMuted ?: false))
    }

    private fun toggleSpeaker() {
        val s = CallService.instance ?: return
        val on = s.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
        s.setAudioRoute(if (on) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
    }

    private fun toggleHold() {
        val c = CallService.instance?.ongoing() ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    private fun dtmf(ch: Char) {
        val c = CallService.instance?.ongoing() ?: return
        c.playDtmfTone(ch)
        typed.append(ch)
        padDigits.text = typed.toString()
        ui.postDelayed({ c.stopDtmfTone() }, 150)
    }

    private fun openMain(tab: Int) {
        val i = Intent(this, MainActivity::class.java)
        i.putExtra("tab", tab)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
        finish()
    }

    private fun refresh() {
        val s = CallService.instance
        val ring = s?.ringing()
        val call = ring ?: s?.ongoing()
        if (s == null || call == null) {
            finish()
            return
        }
        val number = callNumber(call)
        if (number != lastNumber) {
            lastNumber = number
            lastName = lookupName(this, number)
        }
        val name = lastName
        nameTv.text = name ?: number
        subTv.text = if (name != null) number else ""
        subTv.visibility = if (name != null) View.VISIBLE else View.GONE

        val ch = (name ?: number).firstOrNull { it.isLetter() }
        if (ch != null) {
            avatarBg.background = bg(AV_COLORS[((name ?: number).hashCode() and 0x7fffffff) % AV_COLORS.size], circle = true)
            initial.text = ch.toString().uppercase()
            initial.visibility = View.VISIBLE
            person.visibility = View.GONE
        } else {
            avatarBg.background = bg(0xFF4F7F70.toInt(), circle = true)
            initial.visibility = View.GONE
            person.visibility = View.VISIBLE
        }

        val isRing = ring != null
        stateTv.text = when {
            isRing -> "Incoming call"
            call.state == Call.STATE_HOLDING -> "On hold"
            call.state == Call.STATE_ACTIVE -> callElapsed(call)
            else -> "Calling\u2026"
        }
        ringRow.visibility = if (isRing) View.VISIBLE else View.GONE
        endBtn.visibility = if (isRing) View.GONE else View.VISIBLE
        actionGrid.visibility = if (isRing || padShown) View.GONE else View.VISIBLE
        padPanel.visibility = if (!isRing && padShown) View.VISIBLE else View.GONE

        val a = s.callAudioState
        setActive(mute, a?.isMuted ?: false)
        setActive(speaker, a?.route == CallAudioState.ROUTE_SPEAKER)
        setActive(hold, call.state == Call.STATE_HOLDING)
    }

    override fun onResume() {
        super.onResume()
        visible = true
        CallService.instance?.refreshUi()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onPause() {
        visible = false
        ui.removeCallbacks(tick)
        CallService.instance?.refreshUi()
        super.onPause()
    }
}
