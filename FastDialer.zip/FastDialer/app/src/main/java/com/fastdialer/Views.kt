package com.fastdialer

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

fun placeCall(ctx: Context, number: String) {
    val n = number.trim()
    if (n.isEmpty()) return
    try {
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle())
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Please allow the call permission", Toast.LENGTH_SHORT).show()
    }
}

fun openAppSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
        )
    } catch (e: Exception) {
    }
}

/** Recents / Contacts screen: title, search bar and the list (ListView keeps it light) */
class ListScreen(
    private val ctx: Context,
    title: String,
    emptyText: String,
    private val contactsMode: Boolean
) {
    class Row(
        val title: String,
        val sub: String,
        val number: String,
        val missed: Boolean,
        val header: Boolean = false
    )

    private class ItemView(c: Context, pal: Pal, showInfo: Boolean) : LinearLayout(c) {
        val avatarBg = FrameLayout(c)
        val initial: TextView = c.label("", 18f, Color.WHITE, true)
        val person = Glyph(c, Glyph.K_PERSON_FILL)
        val title: TextView = c.label("", 16f, pal.text, true)
        val sub: TextView = c.label("", 12f, pal.sub)
        val info = FrameLayout(c)

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(16), c.dp(8), c.dp(16), c.dp(8))
            initial.gravity = Gravity.CENTER
            person.color = if (pal.dark) 0xFFB0B0B5.toInt() else Color.WHITE
            avatarBg.addView(initial, FrameLayout.LayoutParams(MATCH, MATCH))
            avatarBg.addView(person, FrameLayout.LayoutParams(c.dp(26), c.dp(26), Gravity.CENTER))
            addView(avatarBg, lin(c.dp(44), c.dp(44)))

            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(c.dp(14), 0, c.dp(8), 0)
            title.isSingleLine = true
            title.ellipsize = TextUtils.TruncateAt.END
            sub.isSingleLine = true
            sub.ellipsize = TextUtils.TruncateAt.END
            col.addView(title)
            val sp = lin(WRAP, WRAP)
            sp.topMargin = c.dp(3)
            col.addView(sub, sp)
            addView(col, lin(0, WRAP, 1f))

            if (showInfo) {
                info.background = c.bg(pal.avatar, circle = true)
                val chev = Glyph(c, Glyph.K_CHEVRON)
                chev.color = pal.text
                info.addView(chev, FrameLayout.LayoutParams(c.dp(18), c.dp(18), Gravity.CENTER))
                addView(info, lin(c.dp(32), c.dp(32)))
            }
        }
    }

    var onInfo: ((String) -> Unit)? = null
    var onSearchFocus: ((Boolean) -> Unit)? = null

    private val pal = ctx.palette()
    private val all = ArrayList<Row>()
    private val rows = ArrayList<Row>()
    private var query = ""
    private val list = ListView(ctx)
    val view = FrameLayout(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position].header) 0 else 1
        override fun areAllItemsEnabled() = false
        override fun isEnabled(position: Int) = !rows[position].header

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            if (r.header) {
                val t = (convertView as? TextView) ?: ctx.label("", 12f, pal.sub, true)
                t.setPadding(ctx.dp(20), ctx.dp(14), ctx.dp(20), ctx.dp(4))
                t.text = r.title
                return t
            }
            val v = (convertView as? ItemView) ?: ItemView(ctx, pal, !contactsMode)
            v.title.text = r.title
            v.title.setTextColor(if (r.missed) XI_RED else pal.text)
            v.sub.text = r.sub
            v.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
            val ch = r.title.firstOrNull { it.isLetter() }
            if (ch != null) {
                val col = AV_COLORS[(r.title.hashCode() and 0x7fffffff) % AV_COLORS.size]
                v.avatarBg.background = ctx.bg(col, circle = true)
                v.initial.text = ch.toString().uppercase()
                v.initial.visibility = View.VISIBLE
                v.person.visibility = View.GONE
            } else {
                v.avatarBg.background = ctx.bg(pal.avatar, circle = true)
                v.initial.visibility = View.GONE
                v.person.visibility = View.VISIBLE
            }
            v.info.setOnClickListener { onInfo?.invoke(r.number) }
            return v
        }
    }

    init {
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(0x22888888)
        list.isFastScrollEnabled = contactsMode
        list.setOnItemClickListener { _, _, p, _ ->
            if (p in rows.indices && !rows[p].header) placeCall(ctx, rows[p].number)
        }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        // title bar with the settings gear
        val bar = FrameLayout(ctx)
        bar.addView(
            ctx.label(title, 18f, pal.text, true),
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER)
        )
        val gear = Glyph(ctx, Glyph.K_GEAR)
        gear.color = pal.text
        val gearCell = ctx.iconCell(gear, 22) { openAppSettings(ctx) }
        val gl = FrameLayout.LayoutParams(ctx.dp(48), ctx.dp(48), Gravity.END or Gravity.CENTER_VERTICAL)
        gl.rightMargin = ctx.dp(8)
        bar.addView(gearCell, gl)
        col.addView(bar, lin(MATCH, ctx.dp(52)))

        // search bar
        val sbar = LinearLayout(ctx)
        sbar.orientation = LinearLayout.HORIZONTAL
        sbar.gravity = Gravity.CENTER_VERTICAL
        sbar.background = ctx.bg(pal.fill, 22)
        sbar.setPadding(ctx.dp(14), 0, ctx.dp(8), 0)
        val sg = Glyph(ctx, Glyph.K_SEARCH)
        sg.color = pal.sub
        sbar.addView(sg, lin(ctx.dp(18), ctx.dp(18)))
        val et = EditText(ctx)
        et.hint = "Search contacts"
        et.setHintTextColor(pal.sub)
        et.setTextColor(pal.text)
        et.textSize = 15f
        et.isSingleLine = true
        et.background = null
        et.setPadding(ctx.dp(10), 0, ctx.dp(10), 0)
        et.setOnFocusChangeListener { _, f -> onSearchFocus?.invoke(f) }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                applyFilter()
            }
        })
        sbar.addView(et, lin(0, MATCH, 1f))
        val sl = lin(MATCH, ctx.dp(44))
        sl.setMargins(ctx.dp(16), ctx.dp(6), ctx.dp(16), ctx.dp(8))
        col.addView(sbar, sl)

        if (contactsMode) {
            val ac = ctx.label("All contacts", 13f, pal.sub)
            ac.setPadding(ctx.dp(20), ctx.dp(4), ctx.dp(20), ctx.dp(4))
            col.addView(ac, lin(MATCH, WRAP))
        }

        col.addView(list, lin(MATCH, 0, 1f))
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val empty = ctx.label(emptyText, 14f, pal.sub)
        empty.gravity = Gravity.CENTER
        view.addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        list.emptyView = empty

        if (contactsMode) {
            val fab = FrameLayout(ctx)
            fab.background = ctx.bg(XI_GREEN, circle = true)
            fab.elevation = ctx.dp(6).toFloat()
            val plus = Glyph(ctx, Glyph.K_PLUS)
            plus.color = Color.WHITE
            fab.addView(plus, FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.CENTER))
            fab.setOnClickListener {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI))
                } catch (e: Exception) {
                }
            }
            val fl = FrameLayout.LayoutParams(ctx.dp(56), ctx.dp(56), Gravity.BOTTOM or Gravity.END)
            fl.setMargins(0, 0, ctx.dp(20), ctx.dp(20))
            view.addView(fab, fl)
        }
    }

    private fun applyFilter() {
        rows.clear()
        if (query.isEmpty()) {
            rows.addAll(all)
        } else {
            rows.addAll(all.filter { !it.header && (it.title.contains(query, true) || it.number.contains(query)) })
        }
        adapter.notifyDataSetChanged()
    }

    private fun publish(out: List<Row>) {
        view.post {
            all.clear()
            all.addAll(out)
            applyFilter()
        }
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun loadCalls() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val out = ArrayList<Row>()
            try {
                val args = Bundle()
                args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
                args.putInt(ContentResolver.QUERY_ARG_LIMIT, 100)
                val proj = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE
                )
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val type = c.getInt(2)
                        val date = c.getLong(3)
                        val time = if (DateUtils.isToday(date)) {
                            DateUtils.formatDateTime(ctx, date, DateUtils.FORMAT_SHOW_TIME)
                        } else {
                            DateUtils.formatDateTime(
                                ctx, date, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_ALL
                            )
                        }
                        val hasName = !name.isNullOrBlank()
                        val title = if (hasName) name!! else if (num.isBlank()) "Unknown" else num
                        val sub = time + (if (hasName) " \u2022 $num" else "")
                        out.add(Row(title, sub, num, type == CallLog.Calls.MISSED_TYPE))
                    }
                }
            } catch (_: Exception) {
            }
            publish(out)
        }.start()
    }

    fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val out = ArrayList<Row>()
            val favs = ArrayList<Row>()
            val rest = ArrayList<Row>()
            val seen = HashSet<String>()
            try {
                val pUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val pName = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                val pNum = ContactsContract.CommonDataKinds.Phone.NUMBER
                ctx.contentResolver.query(
                    pUri, arrayOf(pName, pNum, "starred"), null, null,
                    pName + " COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(1) ?: continue
                        val name = c.getString(0) ?: num
                        val starred = c.getInt(2) == 1
                        if (seen.add(name + "|" + num.filter { it.isDigit() })) {
                            if (starred) favs.add(Row(name, num, num, false))
                            else rest.add(Row(name, num, num, false))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (favs.isNotEmpty()) {
                out.add(Row("FAVORITES", "", "", false, true))
                out.addAll(favs)
            }
            var last = ""
            for (r in rest) {
                val ch = r.title.firstOrNull { it.isLetter() }
                val key = if (ch != null) ch.toString().uppercase() else "#"
                if (key != last) {
                    out.add(Row(key, "", "", false, true))
                    last = key
                }
                out.add(r)
            }
            publish(out)
        }.start()
    }
}

/** The keypad sheet: plain numbers (no button backgrounds), menu / green call / dots */
class DialSheet(private val ctx: Context) : LinearLayout(ctx) {
    private val pal = ctx.palette()
    private val sb = StringBuilder()
    private val numView = ctx.label("", 30f, pal.text)
    private val keys = LinearLayout(ctx)
    private val del = ImageView(ctx)
    private val dots = Glyph(ctx, Glyph.K_KEYPAD)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private var expanded = true

    init {
        orientation = LinearLayout.VERTICAL
        background = ctx.bgTop(pal.sheet, 26)
        elevation = ctx.dp(10).toFloat()
        setPadding(0, ctx.dp(8), 0, ctx.dp(4))

        numView.gravity = Gravity.CENTER
        numView.isSingleLine = true
        numView.typeface = light
        numView.visibility = View.GONE
        addView(numView, lin(MATCH, ctx.dp(56)))

        keys.orientation = LinearLayout.VERTICAL
        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to ",", "0" to "+", "#" to "")
        )
        for (r in grid) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for ((d, s) in r) {
                row.addView(key(d, s), lin(0, ctx.dp(60), 1f))
            }
            keys.addView(row, lin(MATCH, WRAP))
        }
        addView(keys, lin(MATCH, WRAP))

        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(0, ctx.dp(2), 0, ctx.dp(8))

        val menu = Glyph(ctx, Glyph.K_MENU)
        menu.color = pal.sub
        val leftCell = ctx.iconCell(menu, 24) { openAppSettings(ctx) }

        dots.color = pal.sub
        del.setImageResource(android.R.drawable.ic_input_delete)
        del.setColorFilter(pal.sub)
        del.scaleType = ImageView.ScaleType.CENTER_INSIDE
        del.visibility = View.GONE
        val rightCell = FrameLayout(ctx)
        rightCell.background = ctx.ripple(Color.TRANSPARENT, 28, rippleColor = 0x22888888)
        rightCell.addView(dots, FrameLayout.LayoutParams(ctx.dp(24), ctx.dp(24), Gravity.CENTER))
        rightCell.addView(del, FrameLayout.LayoutParams(ctx.dp(26), ctx.dp(26), Gravity.CENTER))
        rightCell.setOnClickListener {
            if (sb.isNotEmpty()) {
                sb.deleteCharAt(sb.length - 1)
                update()
            } else {
                toggle()
            }
        }
        rightCell.setOnLongClickListener {
            if (sb.isNotEmpty()) {
                sb.setLength(0)
                update()
                true
            } else {
                false
            }
        }

        val call = ImageView(ctx)
        call.setImageResource(android.R.drawable.sym_action_call)
        call.setColorFilter(Color.WHITE)
        call.scaleType = ImageView.ScaleType.CENTER_INSIDE
        call.setPadding(ctx.dp(18), ctx.dp(18), ctx.dp(18), ctx.dp(18))
        call.background = ctx.ripple(XI_GREEN, circle = true, rippleColor = 0x44FFFFFF)
        call.setOnClickListener { placeCall(ctx, sb.toString()) }

        bottom.addView(leftCell, lin(0, ctx.dp(56), 1f))
        bottom.addView(call, lin(ctx.dp(64), ctx.dp(64)))
        bottom.addView(rightCell, lin(0, ctx.dp(56), 1f))
        addView(bottom, lin(MATCH, WRAP))
    }

    private fun key(d: String, sub: String): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.background = ctx.ripple(Color.TRANSPARENT, 30, rippleColor = 0x22888888)
        col.setOnClickListener {
            sb.append(d)
            update()
        }
        if (d == "0") {
            col.setOnLongClickListener {
                sb.append("+")
                update()
                true
            }
        }
        val num = ctx.label(d, 26f, pal.text)
        num.typeface = light
        col.addView(num)
        val letters = ctx.label(if (sub.isEmpty()) " " else sub, 9f, pal.sub)
        letters.letterSpacing = 0.1f
        col.addView(letters)
        return col
    }

    private fun toggle() {
        expanded = !expanded
        keys.visibility = if (expanded) View.VISIBLE else View.GONE
    }

    fun setNumber(n: String) {
        sb.setLength(0)
        sb.append(n)
        expanded = true
        keys.visibility = View.VISIBLE
        update()
    }

    private fun update() {
        val has = sb.isNotEmpty()
        numView.text = sb.toString()
        numView.textSize = if (sb.length > 12) 22f else 30f
        numView.visibility = if (has) View.VISIBLE else View.GONE
        del.visibility = if (has) View.VISIBLE else View.GONE
        dots.visibility = if (has) View.GONE else View.VISIBLE
    }
}
