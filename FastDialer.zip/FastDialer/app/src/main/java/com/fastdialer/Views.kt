package com.fastdialer

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

fun placeCall(ctx: Context, number: String) {
    val n = number.trim()
    if (n.isEmpty()) return
    try {
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle())
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Call permission allow karein", Toast.LENGTH_SHORT).show()
    }
}

/** Recents / Contacts ki list (ListView: halka aur smooth, koi library nahi) */
class ListScreen(private val ctx: Context, emptyText: String) {
    class Row(val title: String, val sub: String, val number: String, val missed: Boolean)

    private class RowView(c: Context) : LinearLayout(c) {
        val avatar: TextView = c.label("", 18f, Color.WHITE, true)
        val title: TextView = c.label("", 16f, Color.BLACK)
        val sub: TextView = c.label("", 13f, Color.GRAY)

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(16), c.dp(10), c.dp(16), c.dp(10))
            avatar.gravity = Gravity.CENTER
            avatar.background = c.bg(0xFF90A4AE.toInt(), circle = true)
            addView(avatar, lin(c.dp(44), c.dp(44)))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(c.dp(14), 0, 0, 0)
            title.isSingleLine = true
            sub.isSingleLine = true
            col.addView(title)
            val sp = lin(WRAP, WRAP)
            sp.topMargin = c.dp(3)
            col.addView(sub, sp)
            addView(col, lin(0, WRAP, 1f))
        }
    }

    private val rows = ArrayList<Row>()
    private val list = ListView(ctx)
    val view = FrameLayout(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? RowView) ?: RowView(ctx)
            val r = rows[position]
            v.title.text = r.title
            v.title.setTextColor(if (r.missed) 0xFFD93025.toInt() else Color.BLACK)
            v.sub.text = r.sub
            v.avatar.text = r.title.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#"
            return v
        }
    }

    init {
        list.adapter = adapter
        list.divider = null
        list.isFastScrollEnabled = true
        list.setOnItemClickListener { _, _, p, _ -> placeCall(ctx, rows[p].number) }
        val empty = ctx.label(emptyText, 15f, Color.GRAY)
        empty.gravity = Gravity.CENTER
        view.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        list.emptyView = empty
    }

    private fun publish(out: List<Row>) {
        view.post {
            rows.clear()
            rows.addAll(out)
            adapter.notifyDataSetChanged()
        }
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun loadCalls() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val out = ArrayList<Row>()
            try {
                val args = Bundle()
                args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
                args.putInt(ContentResolver.QUERY_ARG_LIMIT, 100)
                val proj = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE
                )
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val type = c.getInt(2)
                        val date = c.getLong(3)
                        val arrow = when (type) {
                            CallLog.Calls.OUTGOING_TYPE -> "↗ "
                            CallLog.Calls.INCOMING_TYPE -> "↙ "
                            else -> "✕ "
                        }
                        val time = DateUtils.formatDateTime(
                            ctx, date,
                            DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_ALL
                        )
                        val hasName = !name.isNullOrBlank()
                        val title = if (hasName) name!! else if (num.isBlank()) "Unknown" else num
                        val sub = arrow + (if (hasName) "$num • " else "") + time
                        out.add(Row(title, sub, num, type == CallLog.Calls.MISSED_TYPE))
                    }
                }
            } catch (_: Exception) {
            }
            publish(out)
        }.start()
    }

    fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val out = ArrayList<Row>()
            val seen = HashSet<String>()
            try {
                val pUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val pName = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                val pNum = ContactsContract.CommonDataKinds.Phone.NUMBER
                ctx.contentResolver.query(
                    pUri, arrayOf(pName, pNum), null, null,
                    pName + " COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(1) ?: continue
                        val name = c.getString(0) ?: num
                        if (seen.add(name + "|" + num.filter { it.isDigit() })) {
                            out.add(Row(name, num, num, false))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            publish(out)
        }.start()
    }
}

/** Samsung jaisa simple keypad */
class DialpadView(private val ctx: Context) : LinearLayout(ctx) {
    private val sb = StringBuilder()
    private val display = ctx.label("", 32f, Color.BLACK)

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        display.gravity = Gravity.CENTER
        display.isSingleLine = true
        addView(display, lin(MATCH, 0, 1f))

        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        val size = ctx.dp(70)
        for (r in grid) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for ((d, s) in r) {
                val lp = lin(size, size)
                lp.setMargins(ctx.dp(12), ctx.dp(5), ctx.dp(12), ctx.dp(5))
                row.addView(key(d, s), lp)
            }
            addView(row)
        }

        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        bottom.setPadding(0, ctx.dp(5), 0, ctx.dp(14))

        val call = ctx.label("Call", 15f, Color.WHITE, true)
        call.gravity = Gravity.CENTER
        call.background = ctx.ripple(0xFF1EA362.toInt(), circle = true, rippleColor = 0x44FFFFFF)
        call.setOnClickListener { placeCall(ctx, sb.toString()) }

        val back = ctx.label("←", 26f, Color.DKGRAY)
        back.gravity = Gravity.CENTER
        back.background = ctx.ripple(Color.TRANSPARENT, circle = true)
        back.setOnClickListener {
            if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
            update()
        }
        back.setOnLongClickListener { sb.setLength(0); update(); true }

        val m = ctx.dp(12)
        val l1 = lin(size, size); l1.setMargins(m, 0, m, 0)
        val l2 = lin(size, size); l2.setMargins(m, 0, m, 0)
        val l3 = lin(size, size); l3.setMargins(m, 0, m, 0)
        bottom.addView(View(ctx), l1)
        bottom.addView(call, l2)
        bottom.addView(back, l3)
        addView(bottom)
    }

    private fun key(d: String, sub: String): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.background = ctx.ripple(0xFFF1F3F4.toInt(), circle = true)
        col.setOnClickListener { sb.append(d); update() }
        if (d == "0") col.setOnLongClickListener { sb.append("+"); update(); true }
        col.addView(ctx.label(d, 26f, Color.BLACK))
        if (sub.isNotEmpty()) col.addView(ctx.label(sub, 9f, Color.GRAY))
        return col
    }

    fun setNumber(n: String) {
        sb.setLength(0)
        sb.append(n)
        update()
    }

    private fun update() {
        display.text = sb.toString()
        display.textSize = if (sb.length > 12) 24f else 32f
    }
}
