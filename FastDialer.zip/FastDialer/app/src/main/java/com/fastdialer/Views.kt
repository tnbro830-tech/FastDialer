package com.fastdialer

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

fun placeCall(ctx: Context, number: String) {
    val n = number.trim()
    if (n.isEmpty()) return
    try {
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", n, null), Bundle())
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Call permission allow karein", Toast.LENGTH_SHORT).show()
    }
}

/** Recents / Contacts ki list: iOS jaisa bada title + patli lines (ListView: halka aur smooth) */
class ListScreen(private val ctx: Context, title: String, emptyText: String) {
    class Row(
        val title: String,
        val sub: String,
        val number: String,
        val missed: Boolean,
        val time: String = ""
    )

    private class RowView(c: Context) : LinearLayout(c) {
        val title: TextView = c.label("", 17f, Color.BLACK)
        val sub: TextView = c.label("", 14f, IOS_GRAY)
        val time: TextView = c.label("", 14f, IOS_GRAY)

        init {
            orientation = LinearLayout.VERTICAL
            val inner = LinearLayout(c)
            inner.orientation = LinearLayout.HORIZONTAL
            inner.gravity = Gravity.CENTER_VERTICAL
            inner.setPadding(c.dp(20), c.dp(11), c.dp(20), c.dp(11))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            title.isSingleLine = true
            sub.isSingleLine = true
            col.addView(title)
            val sp = lin(WRAP, WRAP)
            sp.topMargin = c.dp(2)
            col.addView(sub, sp)
            inner.addView(col, lin(0, WRAP, 1f))
            val lt = lin(WRAP, WRAP)
            lt.leftMargin = c.dp(10)
            inner.addView(time, lt)
            addView(inner, lin(MATCH, WRAP))
            val line = View(c)
            line.setBackgroundColor(IOS_SEP)
            val ll = lin(MATCH, 1)
            ll.leftMargin = c.dp(20)
            addView(line, ll)
        }
    }

    private val rows = ArrayList<Row>()
    private val list = ListView(ctx)
    val view = FrameLayout(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? RowView) ?: RowView(ctx)
            val r = rows[position]
            v.title.text = r.title
            v.title.setTextColor(if (r.missed) IOS_RED else Color.BLACK)
            v.sub.text = r.sub
            v.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
            v.time.text = r.time
            return v
        }
    }

    init {
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = 0
        list.isFastScrollEnabled = true
        list.setOnItemClickListener { _, _, p, _ -> placeCall(ctx, rows[p].number) }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val head = ctx.label(title, 34f, Color.BLACK, true)
        head.setPadding(ctx.dp(20), ctx.dp(16), ctx.dp(20), ctx.dp(10))
        col.addView(head, lin(MATCH, WRAP))
        col.addView(list, lin(MATCH, 0, 1f))

        val empty = ctx.label(emptyText, 17f, IOS_GRAY)
        empty.gravity = Gravity.CENTER
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        list.emptyView = empty
    }

    private fun publish(out: List<Row>) {
        view.post {
            rows.clear()
            rows.addAll(out)
            adapter.notifyDataSetChanged()
        }
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun loadCalls() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val out = ArrayList<Row>()
            try {
                val args = Bundle()
                args.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, CallLog.Calls.DATE + " DESC")
                args.putInt(ContentResolver.QUERY_ARG_LIMIT, 100)
                val proj = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE
                )
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val type = c.getInt(2)
                        val date = c.getLong(3)
                        val kind = when (type) {
                            CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                            CallLog.Calls.INCOMING_TYPE -> "Incoming"
                            else -> "Missed"
                        }
                        val time = if (DateUtils.isToday(date)) {
                            DateUtils.formatDateTime(ctx, date, DateUtils.FORMAT_SHOW_TIME)
                        } else {
                            DateUtils.formatDateTime(
                                ctx, date, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_ALL
                            )
                        }
                        val hasName = !name.isNullOrBlank()
                        val title = if (hasName) name!! else if (num.isBlank()) "Unknown" else num
                        val sub = kind + (if (hasName) " • $num" else "")
                        out.add(Row(title, sub, num, type == CallLog.Calls.MISSED_TYPE, time))
                    }
                }
            } catch (_: Exception) {
            }
            publish(out)
        }.start()
    }

    fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val out = ArrayList<Row>()
            val seen = HashSet<String>()
            try {
                val pUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val pName = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                val pNum = ContactsContract.CommonDataKinds.Phone.NUMBER
                ctx.contentResolver.query(
                    pUri, arrayOf(pName, pNum), null, null,
                    pName + " COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val num = c.getString(1) ?: continue
                        val name = c.getString(0) ?: num
                        if (seen.add(name + "|" + num.filter { it.isDigit() })) {
                            out.add(Row(name, num, num, false))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            publish(out)
        }.start()
    }
}

/** iOS jaisa keypad: gol grey buttons, hara call button */
class DialpadView(private val ctx: Context) : LinearLayout(ctx) {
    private val sb = StringBuilder()
    private val display = ctx.label("", 38f, Color.BLACK)
    private val back = ImageView(ctx)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        display.gravity = Gravity.CENTER
        display.isSingleLine = true
        display.typeface = light
        addView(display, lin(MATCH, 0, 1f))

        val grid = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        val size = ctx.dp(76)
        for (r in grid) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for ((d, s) in r) {
                val lp = lin(size, size)
                lp.setMargins(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
                row.addView(key(d, s), lp)
            }
            addView(row)
        }

        val bottom = LinearLayout(ctx)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        bottom.setPadding(0, ctx.dp(6), 0, ctx.dp(18))

        val call = ImageView(ctx)
        call.setImageResource(android.R.drawable.sym_action_call)
        call.setColorFilter(Color.WHITE)
        call.scaleType = ImageView.ScaleType.CENTER_INSIDE
        call.setPadding(ctx.dp(22), ctx.dp(22), ctx.dp(22), ctx.dp(22))
        call.background = ctx.ripple(IOS_GREEN, circle = true, rippleColor = 0x44FFFFFF)
        call.setOnClickListener { placeCall(ctx, sb.toString()) }

        back.setImageResource(android.R.drawable.ic_input_delete)
        back.setColorFilter(IOS_GRAY)
        back.scaleType = ImageView.ScaleType.CENTER_INSIDE
        back.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(20))
        back.visibility = View.INVISIBLE
        back.setOnClickListener {
            if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
            update()
        }
        back.setOnLongClickListener { sb.setLength(0); update(); true }

        val m = ctx.dp(14)
        val l1 = lin(size, size); l1.setMargins(m, 0, m, 0)
        val l2 = lin(size, size); l2.setMargins(m, 0, m, 0)
        val l3 = lin(size, size); l3.setMargins(m, 0, m, 0)
        bottom.addView(View(ctx), l1)
        bottom.addView(call, l2)
        bottom.addView(back, l3)
        addView(bottom)
    }

    private fun key(d: String, sub: String): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.background = ctx.ripple(IOS_FILL, circle = true)
        col.setOnClickListener { sb.append(d); update() }
        if (d == "0") col.setOnLongClickListener { sb.append("+"); update(); true }
        val num = ctx.label(d, 34f, Color.BLACK)
        num.typeface = light
        col.addView(num)
        if (sub.isNotEmpty()) {
            val letters = ctx.label(sub, 10f, Color.BLACK, true)
            letters.letterSpacing = 0.15f
            col.addView(letters)
        }
        return col
    }

    fun setNumber(n: String) {
        sb.setLength(0)
        sb.append(n)
        update()
    }

    private fun update() {
        display.text = sb.toString()
        display.textSize = if (sb.length > 12) 28f else 38f
        back.visibility = if (sb.isEmpty()) View.INVISIBLE else View.VISIBLE
    }
}
