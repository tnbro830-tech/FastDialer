package com.fastdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var pl: Pal
    private lateinit var banner: TextView
    private lateinit var sheet: DialSheet
    private lateinit var recents: ListScreen
    private lateinit var contacts: ListScreen
    private lateinit var screen0: LinearLayout
    private lateinit var tabRecentsIcon: ImageView
    private lateinit var tabContactsIcon: Glyph
    private lateinit var tabRecentsLabel: TextView
    private lateinit var tabContactsLabel: TextView
    private var tab = 0

    private fun neededPerms(): Array<String> {
        val l = arrayListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun missingPerms() =
        neededPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun isDefaultDialer() =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun tabItem(icon: View, tv: TextView, idx: Int): LinearLayout {
        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        item.gravity = Gravity.CENTER_HORIZONTAL
        item.setPadding(0, dp(8), 0, dp(8))
        item.background = ripple(Color.TRANSPARENT, rippleColor = 0x22888888)
        item.addView(icon, lin(dp(24), dp(24)))
        val tl = lin(WRAP, WRAP)
        tl.topMargin = dp(3)
        item.addView(tv, tl)
        item.setOnClickListener { showTab(idx) }
        return item
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pl = palette()
        window.statusBarColor = pl.bg
        window.navigationBarColor = pl.bg
        window.decorView.systemUiVisibility = if (pl.dark) {
            0
        } else {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        )

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pl.bg)
        root.isFocusableInTouchMode = true

        banner = label("", 14f, Color.WHITE, true)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(16), dp(12), dp(16), dp(12))
        banner.background = bg(XI_GREEN, 12)
        banner.visibility = View.GONE
        banner.setOnClickListener { setupStep() }

        sheet = DialSheet(this)
        recents = ListScreen(this, "Recents", "No recent contacts", false)
        contacts = ListScreen(this, "Contacts", "No contacts", true)
        recents.onInfo = { n -> sheet.setNumber(n) }
        recents.onSearchFocus = { f -> sheet.visibility = if (f) View.GONE else View.VISIBLE }

        screen0 = LinearLayout(this)
        screen0.orientation = LinearLayout.VERTICAL
        screen0.addView(recents.view, lin(MATCH, 0, 1f))
        screen0.addView(sheet, lin(MATCH, WRAP))

        val content = FrameLayout(this)
        content.addView(screen0, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(contacts.view, FrameLayout.LayoutParams(MATCH, MATCH))

        tabRecentsIcon = ImageView(this)
        tabRecentsIcon.setImageResource(android.R.drawable.sym_action_call)
        tabRecentsIcon.scaleType = ImageView.ScaleType.CENTER_INSIDE
        tabContactsIcon = Glyph(this, Glyph.K_PERSON_OUT)
        tabRecentsLabel = label("Recents", 11f, pl.sub)
        tabContactsLabel = label("Contacts", 11f, pl.sub)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(pl.bg)
        bar.addView(tabItem(tabRecentsIcon, tabRecentsLabel, 0), lin(0, WRAP, 1f))
        bar.addView(tabItem(tabContactsIcon, tabContactsLabel, 1), lin(0, WRAP, 1f))

        val bl = lin(MATCH, WRAP)
        bl.setMargins(dp(12), dp(8), dp(12), dp(4))
        root.addView(banner, bl)
        root.addView(content, lin(MATCH, 0, 1f))
        root.addView(bar, lin(MATCH, WRAP))
        setContentView(root)
        root.requestFocus()
        showTab(0)
        handleIntent(intent)
    }

    private fun showTab(i: Int) {
        tab = i
        screen0.visibility = if (i == 0) View.VISIBLE else View.GONE
        contacts.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        val on = pl.text
        val off = pl.sub
        tabRecentsIcon.setColorFilter(if (i == 0) on else off)
        tabContactsIcon.color = if (i == 1) on else off
        tabRecentsLabel.setTextColor(if (i == 0) on else off)
        tabContactsLabel.setTextColor(if (i == 1) on else off)
        tabRecentsLabel.typeface = if (i == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tabContactsLabel.typeface = if (i == 1) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        if (i == 0) recents.loadCalls() else contacts.loadContacts()
    }

    private fun handleIntent(i: Intent?) {
        val it = i ?: return
        if (it.hasExtra("tab")) showTab(it.getIntExtra("tab", 0))
        if (it.action == Intent.ACTION_DIAL) {
            val n = it.data?.schemeSpecificPart
            if (!n.isNullOrEmpty()) {
                sheet.setNumber(n)
                showTab(0)
            }
        }
    }

    private fun refreshBanner() {
        val msg = when {
            missingPerms().isNotEmpty() -> "Step 1: Allow permissions (tap here)"
            !Settings.canDrawOverlays(this) -> "Step 2: Allow the floating overlay permission (tap here)"
            !isDefaultDialer() -> "Step 3: Make this your default Phone app (tap here)"
            else -> null
        }
        if (msg == null) {
            banner.visibility = View.GONE
        } else {
            banner.text = msg
            banner.visibility = View.VISIBLE
        }
    }

    private fun setupStep() {
        val m = missingPerms()
        when {
            m.isNotEmpty() -> requestPermissions(m.toTypedArray(), 1)
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !isDefaultDialer() -> requestDialerRole()
        }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 2)
            }
        } else {
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 2)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBanner()
        showTab(tab)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshBanner()
        showTab(tab)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refreshBanner()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }
}
