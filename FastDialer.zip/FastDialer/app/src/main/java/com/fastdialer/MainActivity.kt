package com.fastdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var banner: TextView
    private lateinit var tabIcons: List<TabIcon>
    private lateinit var tabLabels: List<TextView>
    private lateinit var dialpad: DialpadView
    private lateinit var recents: ListScreen
    private lateinit var contacts: ListScreen
    private var tab = 0

    private fun neededPerms(): Array<String> {
        val l = arrayListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun missingPerms() =
        neededPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun isDefaultDialer() =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = 0xFFF9F9F9.toInt()
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        banner = label("", 14f, Color.WHITE, true)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(16), dp(12), dp(16), dp(12))
        banner.background = bg(IOS_BLUE, 14)
        banner.visibility = View.GONE
        banner.setOnClickListener { setupStep() }

        val content = FrameLayout(this)
        dialpad = DialpadView(this)
        recents = ListScreen(this, "Recents", "No Recents")
        contacts = ListScreen(this, "Contacts", "No Contacts")
        content.addView(dialpad, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(recents.view, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(contacts.view, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xFFF9F9F9.toInt())
        val icons = ArrayList<TabIcon>()
        val labels = ArrayList<TextView>()
        listOf("Keypad", "Recents", "Contacts").forEachIndexed { i, n ->
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, dp(8), 0, dp(6))
            item.background = ripple(0xFFF9F9F9.toInt())
            val ic = TabIcon(this, i)
            val tv = label(n, 10f, IOS_GRAY)
            tv.gravity = Gravity.CENTER
            item.addView(ic, lin(dp(28), dp(26)))
            val tl = lin(WRAP, WRAP)
            tl.topMargin = dp(3)
            item.addView(tv, tl)
            item.setOnClickListener { showTab(i) }
            bar.addView(item, lin(0, WRAP, 1f))
            icons.add(ic)
            labels.add(tv)
        }
        tabIcons = icons
        tabLabels = labels

        val sep = View(this)
        sep.setBackgroundColor(0xFFD1D1D6.toInt())

        val bl = lin(MATCH, WRAP)
        bl.setMargins(dp(12), dp(8), dp(12), dp(4))
        root.addView(banner, bl)
        root.addView(content, lin(MATCH, 0, 1f))
        root.addView(sep, lin(MATCH, 1))
        root.addView(bar, lin(MATCH, WRAP))
        setContentView(root)
        showTab(0)
        handleIntent(intent)
    }

    private fun showTab(i: Int) {
        tab = i
        dialpad.visibility = if (i == 0) View.VISIBLE else View.GONE
        recents.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        contacts.view.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabIcons.forEachIndexed { k, ic -> ic.iconColor = if (k == i) IOS_BLUE else IOS_GRAY }
        tabLabels.forEachIndexed { k, t -> t.setTextColor(if (k == i) IOS_BLUE else IOS_GRAY) }
        if (i == 1) recents.loadCalls()
        if (i == 2) contacts.loadContacts()
    }

    private fun handleIntent(i: Intent?) {
        val it = i ?: return
        if (it.action == Intent.ACTION_DIAL) {
            val n = it.data?.schemeSpecificPart
            if (!n.isNullOrEmpty()) {
                dialpad.setNumber(n)
                showTab(0)
            }
        }
    }

    private fun refreshBanner() {
        val msg = when {
            missingPerms().isNotEmpty() -> "Step 1: Permissions allow karein (tap karein)"
            !Settings.canDrawOverlays(this) -> "Step 2: Floating overlay permission dein (tap karein)"
            !isDefaultDialer() -> "Step 3: Isse default Phone app banayein (tap karein)"
            else -> null
        }
        if (msg == null) {
            banner.visibility = View.GONE
        } else {
            banner.text = msg
            banner.visibility = View.VISIBLE
        }
    }

    private fun setupStep() {
        val m = missingPerms()
        when {
            m.isNotEmpty() -> requestPermissions(m.toTypedArray(), 1)
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !isDefaultDialer() -> requestDialerRole()
        }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 2)
            }
        } else {
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 2)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBanner()
        showTab(tab)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshBanner()
        showTab(tab)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refreshBanner()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }
}
