package com.fastdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var banner: TextView
    private lateinit var tabBtns: List<TextView>
    private lateinit var dialpad: DialpadView
    private lateinit var recents: ListScreen
    private lateinit var contacts: ListScreen
    private var tab = 0

    private fun neededPerms(): Array<String> {
        val l = arrayListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun missingPerms() =
        neededPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun isDefaultDialer() =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        banner = label("", 14f, Color.WHITE, true)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(16), dp(12), dp(16), dp(12))
        banner.background = bg(0xFF1A73E8.toInt())
        banner.visibility = View.GONE
        banner.setOnClickListener { setupStep() }

        val content = FrameLayout(this)
        dialpad = DialpadView(this)
        recents = ListScreen(this, "Koi recent call nahi")
        contacts = ListScreen(this, "Koi contact nahi")
        content.addView(dialpad, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(recents.view, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(contacts.view, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xFFF5F5F5.toInt())
        val btns = ArrayList<TextView>()
        listOf("Keypad", "Recents", "Contacts").forEachIndexed { i, n ->
            val t = label(n, 14f, Color.GRAY, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(16), 0, dp(16))
            t.background = ripple(0xFFF5F5F5.toInt())
            t.setOnClickListener { showTab(i) }
            bar.addView(t, lin(0, WRAP, 1f))
            btns.add(t)
        }
        tabBtns = btns

        root.addView(banner, lin(MATCH, WRAP))
        root.addView(content, lin(MATCH, 0, 1f))
        root.addView(bar, lin(MATCH, WRAP))
        setContentView(root)
        showTab(0)
        handleIntent(intent)
    }

    private fun showTab(i: Int) {
        tab = i
        dialpad.visibility = if (i == 0) View.VISIBLE else View.GONE
        recents.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        contacts.view.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabBtns.forEachIndexed { k, t -> t.setTextColor(if (k == i) 0xFF1A73E8.toInt() else Color.GRAY) }
        if (i == 1) recents.loadCalls()
        if (i == 2) contacts.loadContacts()
    }

    private fun handleIntent(i: Intent?) {
        val it = i ?: return
        if (it.action == Intent.ACTION_DIAL) {
            val n = it.data?.schemeSpecificPart
            if (!n.isNullOrEmpty()) {
                dialpad.setNumber(n)
                showTab(0)
            }
        }
    }

    private fun refreshBanner() {
        val msg = when {
            missingPerms().isNotEmpty() -> "Step 1: Permissions allow karein (tap karein)"
            !Settings.canDrawOverlays(this) -> "Step 2: Floating overlay permission dein (tap karein)"
            !isDefaultDialer() -> "Step 3: Isse default Phone app banayein (tap karein)"
            else -> null
        }
        if (msg == null) {
            banner.visibility = View.GONE
        } else {
            banner.text = msg
            banner.visibility = View.VISIBLE
        }
    }

    private fun setupStep() {
        val m = missingPerms()
        when {
            m.isNotEmpty() -> requestPermissions(m.toTypedArray(), 1)
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !isDefaultDialer() -> requestDialerRole()
        }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 2)
            }
        } else {
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 2)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBanner()
        showTab(tab)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshBanner()
        showTab(tab)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refreshBanner()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }
}
