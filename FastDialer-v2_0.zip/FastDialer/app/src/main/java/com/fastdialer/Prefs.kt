package com.fastdialer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telecom.Call

/** Chhoti si settings (SharedPreferences) + blocked numbers ki list */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("fd_prefs", Context.MODE_PRIVATE)

    // ---- calling ----
    fun proximity(c: Context) = sp(c).getBoolean("proximity", true)
    fun setProximity(c: Context, v: Boolean) = sp(c).edit().putBoolean("proximity", v).apply()

    fun hidePad(c: Context) = sp(c).getBoolean("hidePad", true)
    fun setHidePad(c: Context, v: Boolean) = sp(c).edit().putBoolean("hidePad", v).apply()

    // ---- blocking ----
    fun blockHidden(c: Context) = sp(c).getBoolean("blockHidden", false)
    fun setBlockHidden(c: Context, v: Boolean) = sp(c).edit().putBoolean("blockHidden", v).apply()

    fun blockNonContacts(c: Context) = sp(c).getBoolean("blockNonContacts", false)
    fun setBlockNonContacts(c: Context, v: Boolean) = sp(c).edit().putBoolean("blockNonContacts", v).apply()

    fun blockedCount(c: Context) = sp(c).getInt("blockedCount", 0)
    fun bumpBlocked(c: Context) = sp(c).edit().putInt("blockedCount", blockedCount(c) + 1).apply()

    fun blockedList(c: Context): List<String> =
        (sp(c).getString("blocked", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    private fun saveBlocked(c: Context, l: List<String>) {
        sp(c).edit().putString("blocked", l.joinToString("\n")).apply()
    }

    /** Number ko compare karne ke liye: sirf digits, aakhri 10 */
    fun numKey(n: String): String {
        val d = n.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun isBlocked(c: Context, n: String): Boolean {
        val k = numKey(n)
        return k.isNotEmpty() && blockedList(c).any { numKey(it) == k }
    }

    fun addBlocked(c: Context, n: String) {
        if (n.isBlank() || isBlocked(c, n)) return
        saveBlocked(c, blockedList(c) + n.trim())
    }

    fun removeBlocked(c: Context, n: String) {
        val k = numKey(n)
        saveBlocked(c, blockedList(c).filter { numKey(it) != k })
    }

    // prefix jaise "140" (telemarketer). Kam se kam 3 digit, warna galti se bahut kuch block ho jayega
    fun prefixText(c: Context): String = sp(c).getString("prefixes", "") ?: ""
    fun setPrefixText(c: Context, v: String) = sp(c).edit().putString("prefixes", v.trim()).apply()

    fun prefixes(c: Context): List<String> =
        prefixText(c).split(Regex("[^0-9]+")).filter { it.length >= 3 }
}

/** Incoming call ko pehle hi reject kar do agar block list / rules me aati ho */
object Blocker {
    fun shouldBlock(ctx: Context, call: Call): Boolean {
        val raw = call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
        if (raw == null) return Prefs.blockHidden(ctx)

        if (Prefs.isBlocked(ctx, raw)) return true

        val d = raw.filter { it.isDigit() }
        for (p in Prefs.prefixes(ctx)) {
            if (d.startsWith(p) || d.trimStart('0').startsWith(p)) return true
            if (d.length > 10 && d.takeLast(10).startsWith(p)) return true
        }

        if (Prefs.blockNonContacts(ctx) &&
            ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            lookupName(ctx, raw) == null
        ) return true

        return false
    }
}
