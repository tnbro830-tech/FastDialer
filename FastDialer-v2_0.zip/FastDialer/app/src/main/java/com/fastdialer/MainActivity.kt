package com.fastdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var pl: Pal
    private lateinit var banner: TextView
    private lateinit var sheet: DialSheet
    private lateinit var recents: ListScreen
    private lateinit var contacts: ListScreen
    private lateinit var screen0: FrameLayout
    private lateinit var padFab: FrameLayout
    private var padHidden = false
    private var lastPadChange = 0L
    private var searching = false
    private lateinit var tabRecentsIcon: ImageView
    private lateinit var tabContactsIcon: Glyph
    private lateinit var tabRecentsLabel: TextView
    private lateinit var tabContactsLabel: TextView
    private var tab = 0

    private fun neededPerms(): Array<String> {
        val l = arrayListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun missingPerms() =
        neededPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun isDefaultDialer() =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun tabItem(icon: View, tv: TextView, idx: Int): LinearLayout {
        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        item.gravity = Gravity.CENTER_HORIZONTAL
        item.setPadding(0, dp(8), 0, dp(8))
        item.background = ripple(Color.TRANSPARENT, rippleColor = 0x22888888)
        item.addView(icon, lin(dp(24), dp(24)))
        val tl = lin(WRAP, WRAP)
        tl.topMargin = dp(3)
        item.addView(tv, tl)
        item.setOnClickListener { showTab(idx) }
        return item
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pl = palette()
        window.statusBarColor = pl.bg
        window.navigationBarColor = pl.bg
        window.decorView.systemUiVisibility = if (pl.dark) {
            0
        } else {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        )

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pl.bg)
        root.isFocusableInTouchMode = true

        banner = label("", 14f, Color.WHITE, true)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(16), dp(12), dp(16), dp(12))
        banner.background = bg(XI_GREEN, 12)
        banner.visibility = View.GONE
        banner.setOnClickListener { setupStep() }

        sheet = DialSheet(this)
        recents = ListScreen(this, "Recents", "No recent contacts", false)
        contacts = ListScreen(this, "Contacts", "No contacts", true)
        recents.onInfo = { n ->
            sheet.setNumber(n)
            padHidden = false
            applyPad()
        }
        recents.onSearchFocus = { f ->
            searching = f
            applyPad()
        }
        // list upar scroll karo => dial pad gayab, kone me 3x3 dots button; us pe touch => dial pad wapas
        recents.onScrollUp = {
            if (!padHidden && sheet.isEmpty() && Prefs.hidePad(this) && !padBusy()) {
                padHidden = true
                applyPad()
            }
        }
        // list ko wapas neeche (shuru ki taraf) scroll karo => dial pad apni jagah wapas aa jata hai
        recents.onScrollDown = {
            if (padHidden && !searching && !padBusy()) {
                padHidden = false
                applyPad()
            }
        }

        val col0 = LinearLayout(this)
        col0.orientation = LinearLayout.VERTICAL
        col0.addView(recents.view, lin(MATCH, 0, 1f))
        col0.addView(sheet, lin(MATCH, WRAP))

        padFab = FrameLayout(this)
        padFab.background = bg(XI_GREEN, circle = true)
        padFab.elevation = dp(6).toFloat()
        val padDots = Glyph(this, Glyph.K_KEYPAD)
        padDots.color = Color.WHITE
        padFab.addView(padDots, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        padFab.visibility = View.GONE
        padFab.setOnClickListener {
            padHidden = false
            applyPad()
        }

        screen0 = FrameLayout(this)
        screen0.addView(col0, FrameLayout.LayoutParams(MATCH, MATCH))
        val fabLp = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
        fabLp.setMargins(0, 0, dp(20), dp(20))
        screen0.addView(padFab, fabLp)

        val content = FrameLayout(this)
        content.addView(screen0, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(contacts.view, FrameLayout.LayoutParams(MATCH, MATCH))

        tabRecentsIcon = ImageView(this)
        tabRecentsIcon.setImageResource(R.drawable.ic_call)
        tabRecentsIcon.scaleType = ImageView.ScaleType.CENTER_INSIDE
        tabContactsIcon = Glyph(this, Glyph.K_PERSON_OUT)
        tabRecentsLabel = label("Recents", 11f, pl.sub)
        tabContactsLabel = label("Contacts", 11f, pl.sub)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(pl.bg)
        bar.addView(tabItem(tabRecentsIcon, tabRecentsLabel, 0), lin(0, WRAP, 1f))
        bar.addView(tabItem(tabContactsIcon, tabContactsLabel, 1), lin(0, WRAP, 1f))

        val bl = lin(MATCH, WRAP)
        bl.setMargins(dp(12), dp(8), dp(12), dp(4))
        root.addView(banner, bl)
        root.addView(content, lin(MATCH, 0, 1f))
        root.addView(bar, lin(MATCH, WRAP))
        setContentView(root)
        root.requestFocus()
        showTab(0)
        handleIntent(intent)
    }

    /** Pad abhi abhi hila hai? Tab scroll events ignore (warna pad baar baar upar-neeche hoga) */
    private fun padBusy() = SystemClock.elapsedRealtime() - lastPadChange < 450

    /** Dial pad dikhao / chhupao (scroll pe chhupta hai, wapas scroll ya kone ke dots button se aata hai) */
    private fun applyPad() {
        lastPadChange = SystemClock.elapsedRealtime()
        val showSheet = !padHidden && !searching
        sheet.animate().cancel()
        if (showSheet) {
            sheet.translationY = 0f
            if (sheet.visibility != View.VISIBLE) {
                sheet.alpha = 0f
                sheet.visibility = View.VISIBLE
                sheet.animate().alpha(1f).setDuration(160).start()
            } else {
                sheet.alpha = 1f
            }
        } else if (sheet.visibility == View.VISIBLE) {
            if (searching) {
                sheet.visibility = View.GONE
            } else {
                sheet.animate().translationY(sheet.height.toFloat()).setDuration(170).withEndAction {
                    sheet.visibility = View.GONE
                    sheet.translationY = 0f
                }.start()
            }
        }
        padFab.visibility = if (padHidden && !searching) View.VISIBLE else View.GONE
    }

    private fun showTab(i: Int) {
        tab = i
        screen0.visibility = if (i == 0) View.VISIBLE else View.GONE
        contacts.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        val on = pl.text
        val off = pl.sub
        tabRecentsIcon.setColorFilter(if (i == 0) on else off)
        tabContactsIcon.color = if (i == 1) on else off
        tabRecentsLabel.setTextColor(if (i == 0) on else off)
        tabContactsLabel.setTextColor(if (i == 1) on else off)
        tabRecentsLabel.typeface = if (i == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tabContactsLabel.typeface = if (i == 1) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        if (i == 0) recents.loadCalls() else contacts.loadContacts()
    }

    private fun handleIntent(i: Intent?) {
        val it = i ?: return
        if (it.hasExtra("tab")) showTab(it.getIntExtra("tab", 0))
        if (it.action == Intent.ACTION_DIAL) {
            val n = it.data?.schemeSpecificPart
            if (!n.isNullOrEmpty()) {
                sheet.setNumber(n)
                padHidden = false
                applyPad()
                showTab(0)
            }
        }
    }

    private fun refreshBanner() {
        val msg = when {
            missingPerms().isNotEmpty() -> "Step 1: Allow permissions (tap here)"
            !Settings.canDrawOverlays(this) -> "Step 2: Allow the floating overlay permission (tap here)"
            !isDefaultDialer() -> "Step 3: Make this your default Phone app (tap here)"
            else -> null
        }
        if (msg == null) {
            banner.visibility = View.GONE
        } else {
            banner.text = msg
            banner.visibility = View.VISIBLE
        }
    }

    private fun setupStep() {
        val m = missingPerms()
        when {
            m.isNotEmpty() -> requestPermissions(m.toTypedArray(), 1)
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !isDefaultDialer() -> requestDialerRole()
        }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 2)
            }
        } else {
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 2)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBanner()
        showTab(tab)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshBanner()
        showTab(tab)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refreshBanner()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }
}
