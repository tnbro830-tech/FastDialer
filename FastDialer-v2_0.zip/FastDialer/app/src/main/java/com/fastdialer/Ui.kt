package com.fastdialer

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

const val MATCH = -1
const val WRAP = -2

val XI_GREEN = 0xFF21C55D.toInt()
val XI_RED = 0xFFF0343C.toInt()

val AV_COLORS = intArrayOf(
    0xFFEC407A.toInt(), 0xFF26A69A.toInt(), 0xFF5C6BC0.toInt(), 0xFFFF7043.toInt(),
    0xFF8D6E63.toInt(), 0xFF29B6F6.toInt(), 0xFF66BB6A.toInt(), 0xFFAB47BC.toInt()
)

/** Light / dark colours (follows the phone's theme) */
class Pal(c: Context) {
    val dark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    val bg = if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    val sheet = if (dark) 0xFF161616.toInt() else 0xFFFFFFFF.toInt()
    val text = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    val sub = if (dark) 0xFF8E8E93.toInt() else 0xFF8A8A8E.toInt()
    val fill = if (dark) 0xFF1E1E1E.toInt() else 0xFFF1F1F1.toInt()
    val avatar = if (dark) 0xFF3A3A3C.toInt() else 0xFFD2D2D6.toInt()
}

fun Context.palette(): Pal = Pal(this)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bg(color: Int, radiusDp: Int = 0, circle: Boolean = false): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    if (circle) d.setShape(GradientDrawable.OVAL) else d.setCornerRadius(dp(radiusDp).toFloat())
    return d
}

/** Only the top two corners are round (the keypad sheet) */
fun Context.bgTop(color: Int, radiusDp: Int): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    val r = dp(radiusDp).toFloat()
    d.setCornerRadii(floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f))
    return d
}

fun Context.ripple(
    color: Int, radiusDp: Int = 0, circle: Boolean = false, rippleColor: Int = 0x33000000
): RippleDrawable = RippleDrawable(
    ColorStateList.valueOf(rippleColor), bg(color, radiusDp, circle), bg(Color.WHITE, radiusDp, circle)
)

fun Context.label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    v.setTextColor(color)
    if (bold) v.typeface = Typeface.DEFAULT_BOLD
    v.includeFontPadding = false
    return v
}

fun lin(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

/** A tappable box with an icon in the middle */
fun Context.iconCell(child: View, sizeDp: Int, onClick: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    f.background = ripple(Color.TRANSPARENT, 28, rippleColor = 0x22888888)
    f.setOnClickListener { onClick() }
    f.addView(child, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER))
    return f
}

/** Small icons drawn with Canvas (no image files needed) */
class Glyph(ctx: Context, kind0: Int) : View(ctx) {
    companion object {
        const val K_KEYPAD = 0
        const val K_PERSON_FILL = 1
        const val K_SEARCH = 2
        const val K_GEAR = 3
        const val K_CHEVRON = 4
        const val K_MENU = 5
        const val K_PLUS = 6
        const val K_PERSON_OUT = 7
        const val K_PAUSE = 8
        const val K_MIC = 9
        const val K_MIC_OFF = 10
        const val K_SPEAKER = 11
        const val K_BACKSPACE = 12
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    var kind: Int = kind0
        set(v) {
            field = v
            invalidate()
        }

    var color: Int = 0xFF8E8E93.toInt()
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            K_KEYPAD -> {
                p.style = Paint.Style.FILL
                val g = s * 0.30f
                val r = s * 0.075f
                for (i in 0..2) {
                    for (j in 0..2) {
                        canvas.drawCircle(cx + (i - 1) * g, cy + (j - 1) * g, r, p)
                    }
                }
            }
            K_PERSON_FILL -> {
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy - s * 0.17f, s * 0.18f, p)
                val rect = RectF(cx - s * 0.34f, cy + s * 0.05f, cx + s * 0.34f, cy + s * 0.75f)
                canvas.drawArc(rect, 180f, 180f, true, p)
            }
            K_SEARCH -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.10f
                canvas.drawCircle(cx - s * 0.07f, cy - s * 0.07f, s * 0.30f, p)
                canvas.drawLine(cx + s * 0.15f, cy + s * 0.15f, cx + s * 0.38f, cy + s * 0.38f, p)
            }
            K_GEAR -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.09f
                canvas.drawCircle(cx, cy, s * 0.17f, p)
                canvas.drawCircle(cx, cy, s * 0.31f, p)
                p.strokeWidth = s * 0.13f
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4.0
                    val c = cos(a).toFloat()
                    val sn = sin(a).toFloat()
                    canvas.drawLine(
                        cx + c * s * 0.34f, cy + sn * s * 0.34f,
                        cx + c * s * 0.43f, cy + sn * s * 0.43f, p
                    )
                }
            }
            K_CHEVRON -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.11f
                path.reset()
                path.moveTo(cx - s * 0.10f, cy - s * 0.20f)
                path.lineTo(cx + s * 0.10f, cy)
                path.lineTo(cx - s * 0.10f, cy + s * 0.20f)
                canvas.drawPath(path, p)
            }
            K_MENU -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.09f
                for (j in -1..1) {
                    val y = cy + j * s * 0.22f
                    canvas.drawLine(cx - s * 0.32f, y, cx + s * 0.32f, y, p)
                }
            }
            K_PLUS -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.10f
                canvas.drawLine(cx - s * 0.32f, cy, cx + s * 0.32f, cy, p)
                canvas.drawLine(cx, cy - s * 0.32f, cx, cy + s * 0.32f, p)
            }
            K_PAUSE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.14f
                canvas.drawLine(cx - s * 0.14f, cy - s * 0.24f, cx - s * 0.14f, cy + s * 0.24f, p)
                canvas.drawLine(cx + s * 0.14f, cy - s * 0.24f, cx + s * 0.14f, cy + s * 0.24f, p)
            }
            K_MIC, K_MIC_OFF -> {
                p.style = Paint.Style.FILL
                canvas.drawRoundRect(
                    RectF(cx - s * 0.12f, cy - s * 0.38f, cx + s * 0.12f, cy + s * 0.08f),
                    s * 0.12f, s * 0.12f, p
                )
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.08f
                canvas.drawArc(RectF(cx - s * 0.22f, cy - s * 0.20f, cx + s * 0.22f, cy + s * 0.24f), 0f, 180f, false, p)
                canvas.drawLine(cx, cy + s * 0.24f, cx, cy + s * 0.38f, p)
                canvas.drawLine(cx - s * 0.10f, cy + s * 0.38f, cx + s * 0.10f, cy + s * 0.38f, p)
                if (kind == K_MIC_OFF) {
                    p.strokeWidth = s * 0.09f
                    canvas.drawLine(cx - s * 0.34f, cy - s * 0.34f, cx + s * 0.34f, cy + s * 0.34f, p)
                }
            }
            K_SPEAKER -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx - s * 0.36f, cy - s * 0.10f)
                path.lineTo(cx - s * 0.20f, cy - s * 0.10f)
                path.lineTo(cx - s * 0.02f, cy - s * 0.28f)
                path.lineTo(cx - s * 0.02f, cy + s * 0.28f)
                path.lineTo(cx - s * 0.20f, cy + s * 0.10f)
                path.lineTo(cx - s * 0.36f, cy + s * 0.10f)
                path.close()
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.075f
                canvas.drawArc(RectF(cx - s * 0.12f, cy - s * 0.17f, cx + s * 0.22f, cy + s * 0.17f), -55f, 110f, false, p)
                canvas.drawArc(RectF(cx - s * 0.12f, cy - s * 0.33f, cx + s * 0.38f, cy + s * 0.33f), -55f, 110f, false, p)
            }
            K_BACKSPACE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.08f
                path.reset()
                path.moveTo(cx - s * 0.40f, cy)
                path.lineTo(cx - s * 0.18f, cy - s * 0.28f)
                path.lineTo(cx + s * 0.38f, cy - s * 0.28f)
                path.lineTo(cx + s * 0.38f, cy + s * 0.28f)
                path.lineTo(cx - s * 0.18f, cy + s * 0.28f)
                path.close()
                canvas.drawPath(path, p)
                canvas.drawLine(cx - s * 0.02f, cy - s * 0.10f, cx + s * 0.20f, cy + s * 0.10f, p)
                canvas.drawLine(cx + s * 0.20f, cy - s * 0.10f, cx - s * 0.02f, cy + s * 0.10f, p)
            }
            K_PERSON_OUT -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.09f
                canvas.drawCircle(cx, cy - s * 0.17f, s * 0.15f, p)
                val rect = RectF(cx - s * 0.34f, cy + s * 0.02f, cx + s * 0.34f, cy + s * 0.70f)
                canvas.drawArc(rect, 180f, 180f, false, p)
            }
        }
    }
}
