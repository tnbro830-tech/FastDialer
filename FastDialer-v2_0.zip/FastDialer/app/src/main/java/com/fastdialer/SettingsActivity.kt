package com.fastdialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** In-app Settings: call blocking, calling options, SIM + data usage (Android ka app-info page nahi kholta) */
class SettingsActivity : Activity() {
    private class RowV(val title: TextView, val sub: TextView)

    private lateinit var pl: Pal
    private lateinit var body: LinearLayout
    private lateinit var blockedRow: RowV
    private lateinit var prefixRow: RowV
    private lateinit var statsRow: RowV
    private lateinit var simRow: RowV
    private lateinit var dataRow: RowV

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pl = palette()
        window.statusBarColor = pl.bg
        window.navigationBarColor = pl.bg
        window.decorView.systemUiVisibility = if (pl.dark) {
            0
        } else {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pl.bg)

        val bar = FrameLayout(this)
        val back = Glyph(this, Glyph.K_CHEVRON)
        back.color = pl.text
        back.rotation = 180f
        val backCell = iconCell(back, 22) { finish() }
        val bl = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL)
        bl.leftMargin = dp(8)
        bar.addView(backCell, bl)
        bar.addView(label("Settings", 18f, pl.text, true), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(bar, lin(MATCH, dp(52)))

        val sv = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(sv, lin(MATCH, 0, 1f))
        setContentView(root)

        build()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------- small builders ----------
    private fun section(title: String) {
        val t = label(title.uppercase(), 12f, XI_GREEN, true)
        t.setPadding(dp(20), dp(22), dp(20), dp(6))
        body.addView(t, lin(MATCH, WRAP))
    }

    private fun row(title: String, sub: String, onClick: (() -> Unit)? = null): RowV {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(12))
        val t = label(title, 16f, pl.text)
        val s = label(sub, 13f, pl.sub)
        s.setLineSpacing(0f, 1.15f)
        box.addView(t, lin(MATCH, WRAP))
        val sl = lin(MATCH, WRAP)
        sl.topMargin = dp(3)
        box.addView(s, sl)
        if (onClick != null) {
            box.background = ripple(android.graphics.Color.TRANSPARENT, rippleColor = 0x22888888)
            box.setOnClickListener { onClick() }
        }
        body.addView(box, lin(MATCH, WRAP))
        return RowV(t, s)
    }

    private fun toggle(title: String, sub: String, read: () -> Boolean, write: (Boolean) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(20), dp(12), dp(16), dp(12))
        box.background = ripple(android.graphics.Color.TRANSPARENT, rippleColor = 0x22888888)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 16f, pl.text), lin(MATCH, WRAP))
        val s = label(sub, 13f, pl.sub)
        s.setLineSpacing(0f, 1.15f)
        val sl = lin(MATCH, WRAP)
        sl.topMargin = dp(3)
        col.addView(s, sl)
        box.addView(col, lin(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = read()
        sw.setOnCheckedChangeListener { _, on -> write(on) }
        val swl = lin(WRAP, WRAP)
        swl.leftMargin = dp(12)
        box.addView(sw, swl)
        box.setOnClickListener { sw.toggle() }
        body.addView(box, lin(MATCH, WRAP))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------- screen ----------
    private fun build() {
        section("Call blocking")
        toggle(
            "Block hidden / private numbers",
            "Calls that come without any number are rejected automatically",
            { Prefs.blockHidden(this) }
        ) { Prefs.setBlockHidden(this, it) }
        toggle(
            "Block numbers not in contacts",
            "Every unsaved number is rejected. Careful: delivery, bank and doctor calls get blocked too",
            { Prefs.blockNonContacts(this) }
        ) { Prefs.setBlockNonContacts(this, it) }
        blockedRow = row("Blocked numbers", "") { manageBlocked() }
        prefixRow = row("Block by prefix", "") { prefixDialog() }
        statsRow = row("Blocked calls so far", "")

        section("Calling")
        toggle(
            "Screen off near ear",
            "Screen turns off when phone is at your ear during a call and turns on when you move it away",
            { Prefs.proximity(this) }
        ) { Prefs.setProximity(this, it) }
        toggle(
            "Hide dial pad on scroll",
            "Dial pad slides down when you scroll recents, and comes back when you scroll the other way",
            { Prefs.hidePad(this) }
        ) { Prefs.setHidePad(this, it) }

        section("SIM & data usage")
        simRow = row("SIM cards", "") { askPhoneState() }
        dataRow = row("Mobile data used", "") { dataClick() }

        section("More")
        row("Phone permissions & battery", "Opens Android settings (set Battery to Unrestricted here)") {
            openAppSettings(this)
        }
        row("Fast Dialer", "Version 2.0", null)
        val pad = View(this)
        body.addView(pad, lin(MATCH, dp(32)))
    }

    private fun refresh() {
        val bl = Prefs.blockedList(this)
        blockedRow.sub.text = if (bl.isEmpty()) {
            "None yet. Tap to add a number"
        } else {
            "${bl.size} blocked. Tap to view or unblock"
        }
        val pf = Prefs.prefixes(this)
        prefixRow.sub.text = if (pf.isEmpty()) {
            "Off. Example: 140 blocks telemarketing numbers"
        } else {
            "Blocking numbers starting with " + pf.joinToString(", ")
        }
        statsRow.sub.text = Prefs.blockedCount(this).toString()

        simRow.sub.text = if (hasPhoneState()) simText() else "Tap to allow SIM info"
        loadData()
    }

    // ---------- blocking dialogs ----------
    private fun wrap(et: EditText): FrameLayout {
        val w = FrameLayout(this)
        w.setPadding(dp(20), dp(8), dp(20), 0)
        w.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        return w
    }

    private fun manageBlocked() {
        val list = Prefs.blockedList(this)
        if (list.isEmpty()) {
            addBlockedDialog()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Blocked numbers (tap one to unblock)")
            .setItems(list.toTypedArray()) { _, i ->
                Prefs.removeBlocked(this, list[i])
                toast("Unblocked")
                refresh()
            }
            .setPositiveButton("Add number") { _, _ -> addBlockedDialog() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun addBlockedDialog() {
        val et = EditText(this)
        et.hint = "Phone number"
        et.inputType = InputType.TYPE_CLASS_PHONE
        et.isSingleLine = true
        AlertDialog.Builder(this)
            .setTitle("Block a number")
            .setView(wrap(et))
            .setPositiveButton("Block") { _, _ ->
                val n = et.text.toString().trim()
                if (n.count { it.isDigit() } >= 3) {
                    Prefs.addBlocked(this, n)
                    toast("Blocked")
                    refresh()
                } else {
                    toast("Enter a valid number")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun prefixDialog() {
        val et = EditText(this)
        et.hint = "140, 160 (3+ digits each)"
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.isSingleLine = true
        et.setText(Prefs.prefixText(this))
        AlertDialog.Builder(this)
            .setTitle("Block numbers starting with")
            .setView(wrap(et))
            .setPositiveButton("Save") { _, _ ->
                Prefs.setPrefixText(this, et.text.toString())
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- SIM ----------
    private fun hasPhoneState() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun askPhoneState() {
        if (!hasPhoneState()) requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 5)
    }

    private fun simText(): String = try {
        val sm = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        val l = sm.activeSubscriptionInfoList
        if (l.isNullOrEmpty()) {
            "No active SIM found"
        } else {
            l.joinToString("\n") { "SIM " + (it.simSlotIndex + 1) + ": " + (it.carrierName ?: it.displayName ?: "") }
        }
    } catch (_: Exception) {
        "SIM info not available"
    }

    // ---------- data usage ----------
    private fun hasUsageAccess(): Boolean = try {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
            AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }

    private fun dataClick() {
        if (hasUsageAccess()) {
            loadData()
            return
        }
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    private fun mobileBytes(from: Long, to: Long): Long = try {
        val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        var sid: String? = null
        if (Build.VERSION.SDK_INT < 29) {
            try {
                sid = (getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).subscriberId
            } catch (_: Exception) {
            }
        }
        val b = nsm.querySummaryForDevice(ConnectivityManager.TYPE_MOBILE, sid, from, to)
        b.rxBytes + b.txBytes
    } catch (_: Exception) {
        -1L
    }

    private fun fmt(b: Long): String = when {
        b < 0 -> "N/A"
        b < 1024L * 1024 -> (b / 1024).toString() + " KB"
        b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.2f GB".format(b / 1073741824.0)
    }

    private fun loadData() {
        if (!hasUsageAccess()) {
            dataRow.sub.text = "Tap here and allow \"Usage access\" for Fast Dialer, then come back"
            return
        }
        dataRow.sub.text = "Checking\u2026"
        Thread {
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val today = cal.timeInMillis
            cal.set(Calendar.DAY_OF_MONTH, 1)
            val month = cal.timeInMillis
            val t = mobileBytes(today, now)
            val w = mobileBytes(now - 7L * 24 * 3600 * 1000, now)
            val m = mobileBytes(month, now)
            val text = if (t < 0 && w < 0 && m < 0) {
                "Not available on this phone"
            } else {
                "Today: " + fmt(t) + "\nLast 7 days: " + fmt(w) + "\nThis month: " + fmt(m) +
                    "\n(mobile data of all SIMs together, Wi-Fi not counted)"
            }
            runOnUiThread { dataRow.sub.text = text }
        }.start()
    }
}
