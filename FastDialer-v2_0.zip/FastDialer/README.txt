FAST DIALER 2  (v2.0) - ye NAYI ALAG APP hai, purani Fast Dialer ka update nahi.
- Naya app id: com.fastdialer.two  => purani Fast Dialer ke saath saath install hoti hai, kuch overwrite nahi hota.
- Naam: "Fast Dialer 2", icon ka rang neela (purani ka hara).
- Naye app ko default Phone app banana padega (ek hi dialer default ho sakta hai). Permissions bhi dobara deni padengi.
- Is me purani v1.3 ke saare changes hain (neeche padho).

GITHUB se build: is zip ko repo me upload karo (nam FastDialer-v2_0.zip), baaki workflow wahi.

------------------------------------------------------------

FAST DIALER - floating call UI wala lightweight dialer

PHONE PE BUILD (AndroidIDE app se):
1. AndroidIDE install karo (github.com/AndroidIDEOfficial/AndroidIDE releases, arm64-v8a APK).
2. Pehli baar kholo: storage permission do aur setup/packages install hone do (internet chahiye).
3. MT Manager se FastDialer.zip ko extract karo (FastDialer folder banega).
4. AndroidIDE > Open existing project > FastDialer folder (jisme settings.gradle.kts hai).
5. Gradle sync poora hone do (pehli baar internet se files download hongi, 10-20 min).
6. Build > Run / assembleDebug. APK milega: app/build/outputs/apk/debug/app-debug.apk

APK install ke baad app kholo, upar blue banner ke 3 steps follow karo:
permissions -> overlay permission -> default Phone app.
Settings > Battery > Fast Dialer > Unrestricted bhi kar dena.

GITHUB se build karna ho to .github/workflows/build.yml dekho.

--- v1.1 (naye changes) ---
- Incoming call: Decline / Answer ke beech zyada gap (floating card me bhi, full screen me bhi: ek left ek right).
- Call ke dauran floating pill ab top-center me hi aati hai (jahan incoming card aata hai).
- Lock screen pe: ongoing call notification -> status bar me phone icon (Android 12+ pe green call chip + timer).
  Us pe touch karo to call screen khul jati hai. (Lock screen pe overlay Android allow nahi karta, isliye notification.)
- Proximity sensor: call me phone kaan pe lagao -> screen off, hatao -> screen on
  (speaker / bluetooth / headset pe screen on rehti hai, ringing me off nahi hoti).
- Home (Recents) screen: list upar scroll karo -> dial pad gayab, neeche kone me 3x3 dots button; us pe touch -> dial pad wapas.
  (Number type kiya hua ho to dial pad nahi chhupta.)
- Unknown number: saved contact nahi to network wala caller name upar dikhta hai (jaise default dialer). "CNAP" ka label kahin nahi.
- Recents me Incoming / Outgoing / Missed / Declined likha aata hai.
- Naye permission: WAKE_LOCK (proximity ke liye, normal permission hai, popup nahi aata).

--- v1.2 (naye changes) ---
- Incoming floating card: Decline sabse left kone me, Answer sabse right kone me, beech me naam/number
  (pehle dono buttons paas paas the). Full-screen incoming screen pehle se left/right hai.
- Lock screen / status bar ka hara call chip: call notification ab foreground service (phoneCall) se judi hai,
  jisse Android 12+ pe chip aane ki sambhavna badh jaati hai (kuch phones me company ki skin alag behave karti hai). Agar system mana kare to pehle jaisi normal notification.
  (Naye permission: FOREGROUND_SERVICE, FOREGROUND_SERVICE_PHONE_CALL - normal hain, popup nahi aata.)
- Recents me ab call ki duration bhi dikhti hai (jaise "Incoming - 3:45 PM - 1m 23s").
- Recents me kisi row ko dabake rakho (long press) => us number ki poori call history
  (type, date/time, duration) + Call button.

--- v1.3 (naye changes) ---
- Dial pad: list ko upar scroll karo => pad neeche chala jata hai; wapas neeche (shuru ki taraf) scroll karo => pad apni jagah
  wapas aa jata hai. Kone ke dots button se bhi wapas aata hai.
- Gear / menu icon ab Android ka "App info" nahi kholta, app ki apni Settings screen kholta hai:
  * Call blocking: hidden/private numbers block, contacts me na hone wale numbers block, number list (add/unblock),
    prefix se block (jaise 140 telemarketing), kitni calls block hui.
  * Calling: kaan pe screen off (on/off), scroll pe dial pad chhupana (on/off).
  * SIM & data usage: active SIM ke naam, aaj / pichle 7 din / is mahine ka mobile data.
    Pehli baar "Usage access" permission deni padegi (Settings me Fast Dialer ko allow karo).
    Android per-SIM alag data nahi batane deta, isliye dono SIM ka mobile data total dikhta hai (Wi-Fi nahi).
  * Phone permissions & battery: Android ki settings kholta hai (Battery > Unrestricted ke liye).
- Recents me kisi row ko dabake rakho => history dialog me ab "Block" button bhi hai.
- Block ki hui incoming call seedha reject ho jati hai (phone ring nahi hota).
- Naye permission: READ_PHONE_STATE (SIM naam), PACKAGE_USAGE_STATS (data usage; Usage access se dena padta hai).
